-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 06, 2021 at 05:04 PM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbse3`
--

-- --------------------------------------------------------

--
-- Table structure for table `tblcollege`
--

CREATE TABLE `tblcollege` (
  `id` int(200) NOT NULL,
  `collegecode` varchar(20) NOT NULL,
  `college` varchar(100) NOT NULL,
  `seal` varchar(20) NOT NULL,
  `admin_exist` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblcollege`
--

INSERT INTO `tblcollege` (`id`, `collegecode`, `college`, `seal`, `admin_exist`) VALUES
(84, 'ICS', 'Institute of Computer Studies ', 'ics.png', 1),
(85, 'CN', 'College of Nursing', 'cn-.png', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblcourse`
--

CREATE TABLE `tblcourse` (
  `id` int(200) NOT NULL,
  `coursecode` varchar(20) NOT NULL,
  `course` varchar(100) NOT NULL,
  `yearlevels` int(5) NOT NULL,
  `collegeid_fk` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblcourse`
--

INSERT INTO `tblcourse` (`id`, `coursecode`, `course`, `yearlevels`, `collegeid_fk`) VALUES
(26, 'BSCS', 'Bachelor of Science in Computer Science', 1, 84),
(27, 'BSN', 'Bachelor of Science in Nursing', 1, 85);

-- --------------------------------------------------------

--
-- Table structure for table `tblcurriculum`
--

CREATE TABLE `tblcurriculum` (
  `id` int(50) NOT NULL,
  `curr_code` varchar(200) NOT NULL,
  `cmo` varchar(50) NOT NULL,
  `board_reso` varchar(50) NOT NULL,
  `effectiveSY` varchar(50) NOT NULL,
  `collegeid_fk` int(100) NOT NULL,
  `course_id_fk` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblcurriculum`
--

INSERT INTO `tblcurriculum` (`id`, `curr_code`, `cmo`, `board_reso`, `effectiveSY`, `collegeid_fk`, `course_id_fk`) VALUES
(48, '(2010      -      2015)', 'CMO1', 'BR1', '2010      -      2015', 85, 27);

-- --------------------------------------------------------

--
-- Table structure for table `tblrequestadviser`
--

CREATE TABLE `tblrequestadviser` (
  `id` int(200) NOT NULL,
  `course_id_fk` int(200) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(10) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `yearlevel` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tblrequeststudent`
--

CREATE TABLE `tblrequeststudent` (
  `id` int(100) NOT NULL,
  `course_id_fk` int(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `yearlevel` int(100) NOT NULL,
  `college_id_fk` int(100) NOT NULL,
  `adviser` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblrequeststudent`
--

INSERT INTO `tblrequeststudent` (`id`, `course_id_fk`, `email`, `password`, `firstname`, `lastname`, `status`, `yearlevel`, `college_id_fk`, `adviser`) VALUES
(1, 27, 'niko@gmail.com', 'nikoNIKO1;', 'Niko', 'Fernandez', 'New Student', 1, 85, 'ana'),
(4, 27, 'sadz@gmail.com', 'Sadzpueblo130:', 'sadz', 'pueblo', 'Old Student', 2, 85, 'tony');

-- --------------------------------------------------------

--
-- Table structure for table `tblrequest_account`
--

CREATE TABLE `tblrequest_account` (
  `id` int(200) NOT NULL,
  `course_id_fk` int(200) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(10) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `yearlevel` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblrequest_account`
--

INSERT INTO `tblrequest_account` (`id`, `course_id_fk`, `email`, `password`, `usertype`, `firstname`, `lastname`, `yearlevel`) VALUES
(4, 23, '', 'a123', 'Adviser', 'Reniel', 'Tumacas', 3),
(5, 23, '', 'a', 'Adviser', 'sdv', 'dss', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tblsections`
--

CREATE TABLE `tblsections` (
  `id` int(200) NOT NULL,
  `sectioncode` varchar(100) NOT NULL,
  `section_name` varchar(50) NOT NULL,
  `number_of_students` int(200) NOT NULL,
  `available_slots` int(200) NOT NULL,
  `total_slots` int(100) NOT NULL,
  `yearlevel` int(100) NOT NULL,
  `course_id_fk` int(200) NOT NULL,
  `college` int(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblsections`
--

INSERT INTO `tblsections` (`id`, `sectioncode`, `section_name`, `number_of_students`, `available_slots`, `total_slots`, `yearlevel`, `course_id_fk`, `college`) VALUES
(6, 'sl23131', 'A', 3, 40, 37, 1, 27, 85),
(7, 'sl23132', 'B', 3, 50, 47, 1, 27, 85),
(8, 'sl231312', 'A', 3, 50, 0, 2, 27, 85);

-- --------------------------------------------------------

--
-- Table structure for table `tblsubject`
--

CREATE TABLE `tblsubject` (
  `id` int(100) NOT NULL,
  `subjectid` varchar(100) NOT NULL,
  `curr_id_fk` int(200) NOT NULL,
  `subject_code` varchar(50) NOT NULL,
  `sub_type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `lec` int(10) NOT NULL,
  `lab` int(10) NOT NULL,
  `units` int(50) NOT NULL,
  `time` varchar(100) NOT NULL,
  `day` varchar(100) NOT NULL,
  `college` int(200) NOT NULL,
  `course` int(100) NOT NULL,
  `prereq` varchar(50) NOT NULL,
  `semester` varchar(20) NOT NULL,
  `year` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblsubject`
--

INSERT INTO `tblsubject` (`id`, `subjectid`, `curr_id_fk`, `subject_code`, `sub_type`, `title`, `lec`, `lab`, `units`, `time`, `day`, `college`, `course`, `prereq`, `semester`, `year`) VALUES
(0, 'cs22131', 48, 'faw34', 'none', 'none', 2, 4, 5, '8:30-10:00 am', 'MWF', 85, 27, 'none', '1st semester', 1),
(1, 'cn23131', 48, 'CN101', 'Sciences', 'Lecture', 2, 3, 6, '7:00 - 8:30am', 'MW', 85, 27, 'cn231312', '1st Semester', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblsub_grades`
--

CREATE TABLE `tblsub_grades` (
  `id` int(100) NOT NULL,
  `subject_code1` varchar(100) NOT NULL,
  `grades1` varchar(100) NOT NULL,
  `subject_code2` varchar(100) NOT NULL,
  `grades2` varchar(100) NOT NULL,
  `subject_code3` varchar(100) NOT NULL,
  `grades3` varchar(100) NOT NULL,
  `subject_code4` varchar(100) NOT NULL,
  `grades4` varchar(100) NOT NULL,
  `subject_code5` varchar(100) NOT NULL,
  `grades5` varchar(100) NOT NULL,
  `subject_code6` varchar(100) NOT NULL,
  `grades6` varchar(100) NOT NULL,
  `subject_code7` varchar(100) NOT NULL,
  `grades7` varchar(100) NOT NULL,
  `subject_code8` varchar(100) NOT NULL,
  `grades8` varchar(100) NOT NULL,
  `subject_code9` varchar(100) NOT NULL,
  `grades9` varchar(100) NOT NULL,
  `subject_code10` varchar(100) NOT NULL,
  `grades10` varchar(100) NOT NULL,
  `student_email` varchar(100) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `section` varchar(100) NOT NULL,
  `status` varchar(100) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `pdf_grades` varchar(100) NOT NULL,
  `college_id_fk` int(100) NOT NULL,
  `courseid_fk` int(100) NOT NULL,
  `yearlevel` int(100) NOT NULL,
  `adviser_email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblsub_grades`
--

INSERT INTO `tblsub_grades` (`id`, `subject_code1`, `grades1`, `subject_code2`, `grades2`, `subject_code3`, `grades3`, `subject_code4`, `grades4`, `subject_code5`, `grades5`, `subject_code6`, `grades6`, `subject_code7`, `grades7`, `subject_code8`, `grades8`, `subject_code9`, `grades9`, `subject_code10`, `grades10`, `student_email`, `firstname`, `lastname`, `section`, `status`, `comment`, `pdf_grades`, `college_id_fk`, `courseid_fk`, `yearlevel`, `adviser_email`) VALUES
(66, 'cc101', '1.00', 'cc102', '1.00', 'cc103', '1.00', 'cc104', '1.00', 'cc105', '1.00', 'cc106', '1.00', 'cc107', '1.00', 'cc108', '1.00', 'cc109', '1.00', 'cc110', '1.00', 'sadz@gmail.com', 'sadz', 'pueblo', 'A', 'Disapprove', 'rew', '', 85, 27, 1, 'ana'),
(76, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'sadz@gmail.com', 'sadz', 'pueblo', 'A', 'Pending Approval', '', '', 85, 27, 1, 'ana'),
(77, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'sadz@gmail.com', 'sadz', 'pueblo', 'A', 'Pending Approval', '', '', 85, 27, 1, 'ana'),
(78, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'sadz@gmail.com', 'sadz', 'pueblo', 'A', 'Pending Approval', '', '', 85, 27, 1, 'ana'),
(79, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'lupin', 'lupin', 'lupin', 'A', 'Pending Approval', '', '', 84, 26, 1, 'eureka'),
(80, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'sadz@gmail.com', 'sadz', 'pueblo', 'A', 'Pending Approval', '', '', 85, 27, 1, 'ana');

-- --------------------------------------------------------

--
-- Table structure for table `tblusers`
--

CREATE TABLE `tblusers` (
  `id` int(100) NOT NULL,
  `college_id_fk` int(200) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `usertype` varchar(20) NOT NULL,
  `date_created` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `uniId` varchar(100) NOT NULL,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `contact` int(11) NOT NULL,
  `picture` varchar(100) NOT NULL,
  `status` int(5) NOT NULL,
  `per_status` varchar(100) NOT NULL,
  `courseid_fk` int(20) NOT NULL,
  `sectionid_fk` int(20) NOT NULL,
  `yearlevel` int(5) NOT NULL,
  `already_assigned` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tblusers`
--

INSERT INTO `tblusers` (`id`, `college_id_fk`, `email`, `password`, `usertype`, `date_created`, `uniId`, `firstname`, `lastname`, `contact`, `picture`, `status`, `per_status`, `courseid_fk`, `sectionid_fk`, `yearlevel`, `already_assigned`) VALUES
(1, 0, 'tumacas@gmail.com', 'a123', 'Superadmin', '2021-05-03 13:59:08', '', 'Reniel', 'Tumacas', 983223, '', 1, '0', 0, 0, 0, 1),
(5, 84, 'tom', 'tom', 'Admin', '2021-05-03 13:59:11', '', 'Tom', 'Holland', 0, 'tom1.jpg', 1, '0', 0, 0, 0, 1),
(6, 85, 'tony', 'tony', 'Admin', '2021-05-03 13:59:14', '', 'Tony', 'Stark', 986554, 'Tony-Stark.jpg', 1, '0', 0, 0, 0, 1),
(7, 85, 'ana', 'ana', 'Adviser', '2021-05-06 08:54:58', '', 'Ana', 'Makili', 0, '', 1, '0', 27, 0, 1, 1),
(8, 85, 'sadz@gmail.com', 'sadz', 'Student', '2021-05-05 16:24:21', 'sl201100519', 'sadz', 'pueblo', 0, '', 1, 'Old Student', 27, 0, 1, 0),
(9, 85, 'steven@gmail.com', 'saSA11::', 'Student', '2021-05-05 04:44:40', 'sl20112332', 'Steven', 'Fernandez', 0, '', 1, 'New Student', 27, 0, 1, 0),
(14, 85, 'steve@gmail.com', '', 'Student', '2021-05-05 04:44:55', 'steve', 'steve', 'Fernandcez', 0, '', 1, 'New Student', 27, 0, 1, 0),
(16, 84, 'eureka', 'eureka', 'Adviser', '2021-05-05 16:51:49', '', 'eureka', 'wewe', 0, '', 1, '0', 26, 0, 1, 1),
(18, 84, 'lupin', 'lupin', 'Student', '2021-05-06 14:26:23', '', 'lupin', 'lupin', 0, '', 1, '0', 26, 0, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tblcollege`
--
ALTER TABLE `tblcollege`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblcourse`
--
ALTER TABLE `tblcourse`
  ADD PRIMARY KEY (`id`),
  ADD KEY `collegeid_fk` (`collegeid_fk`);

--
-- Indexes for table `tblcurriculum`
--
ALTER TABLE `tblcurriculum`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id_fk` (`course_id_fk`),
  ADD KEY `tblcollege` (`collegeid_fk`);

--
-- Indexes for table `tblrequestadviser`
--
ALTER TABLE `tblrequestadviser`
  ADD PRIMARY KEY (`id`),
  ADD KEY `course_id_fk` (`course_id_fk`);

--
-- Indexes for table `tblrequeststudent`
--
ALTER TABLE `tblrequeststudent`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblrequest_account`
--
ALTER TABLE `tblrequest_account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblsections`
--
ALTER TABLE `tblsections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tblcollegeid` (`college`),
  ADD KEY `tblcourseid` (`course_id_fk`);

--
-- Indexes for table `tblsubject`
--
ALTER TABLE `tblsubject`
  ADD PRIMARY KEY (`id`),
  ADD KEY `curr_id_fk` (`curr_id_fk`),
  ADD KEY `tblcourse_fk` (`course`),
  ADD KEY `college` (`college`);

--
-- Indexes for table `tblsub_grades`
--
ALTER TABLE `tblsub_grades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `college_id_fk` (`college_id_fk`),
  ADD KEY `courseid_fk` (`courseid_fk`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tblcollege`
--
ALTER TABLE `tblcollege`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;

--
-- AUTO_INCREMENT for table `tblcourse`
--
ALTER TABLE `tblcourse`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `tblcurriculum`
--
ALTER TABLE `tblcurriculum`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `tblrequestadviser`
--
ALTER TABLE `tblrequestadviser`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblrequeststudent`
--
ALTER TABLE `tblrequeststudent`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tblrequest_account`
--
ALTER TABLE `tblrequest_account`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `tblsections`
--
ALTER TABLE `tblsections`
  MODIFY `id` int(200) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `tblsub_grades`
--
ALTER TABLE `tblsub_grades`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tblcourse`
--
ALTER TABLE `tblcourse`
  ADD CONSTRAINT `collegeid_fk` FOREIGN KEY (`collegeid_fk`) REFERENCES `tblcollege` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblcurriculum`
--
ALTER TABLE `tblcurriculum`
  ADD CONSTRAINT `tblcollege` FOREIGN KEY (`collegeid_fk`) REFERENCES `tblcollege` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tblcurriculum_ibfk_1` FOREIGN KEY (`course_id_fk`) REFERENCES `tblcourse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblrequestadviser`
--
ALTER TABLE `tblrequestadviser`
  ADD CONSTRAINT `tblrequestadviser_ibfk_1` FOREIGN KEY (`course_id_fk`) REFERENCES `tblcourse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblsections`
--
ALTER TABLE `tblsections`
  ADD CONSTRAINT `tblcollegeid` FOREIGN KEY (`college`) REFERENCES `tblcollege` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tblcourseid` FOREIGN KEY (`course_id_fk`) REFERENCES `tblcourse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblsubject`
--
ALTER TABLE `tblsubject`
  ADD CONSTRAINT `college` FOREIGN KEY (`college`) REFERENCES `tblcollege` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tblcourse_fk` FOREIGN KEY (`course`) REFERENCES `tblcourse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tblsubject_ibfk_1` FOREIGN KEY (`curr_id_fk`) REFERENCES `tblcurriculum` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tblsub_grades`
--
ALTER TABLE `tblsub_grades`
  ADD CONSTRAINT `college_id_fk` FOREIGN KEY (`college_id_fk`) REFERENCES `tblcollege` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `courseid_fk` FOREIGN KEY (`courseid_fk`) REFERENCES `tblcourse` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
