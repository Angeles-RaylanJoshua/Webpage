 <!-- ALERT MESSAGE-->
 <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!--Added Succesfully Message-->
<?php
    if(isset($_SESSION['admin_alert_message']) && $_SESSION['admin_alert_message'] == "added" )
    {
        ?>
            <script>
                swal({
                    title: "Admin Successfully Added",
                    icon: "success",
                });
            </script>
        <?php
        unset($_SESSION['admin_alert_message'] );
    }
?>
<!--Updated Succesfully Message-->
<?php
    if(isset($_SESSION['admin_alert_message']) && $_SESSION['admin_alert_message'] == "updated" )
    {
        ?>
            <script>
                swal({
                    title: "Admin Successfully Updated!",
                    icon: "success",
                });
            </script>
        <?php
        unset($_SESSION['admin_alert_message'] );
    }
?>
<!--Delete Succesfully Message-->
<?php
    if(isset($_SESSION['admin_alert_message']) && $_SESSION['admin_alert_message'] == "deleted" )
    {
        ?>
            <script>
                swal(
                    title: "Admin Successfully Deleted!",
                    icon: "success",
                });
            </script>
        <?php
        unset($_SESSION['admin_alert_message'] );
    }
?>

<!--Warning Message-->
<?php
    if(isset($_SESSION['admin_alert_message']) && $_SESSION['admin_alert_message'] == "courseexisted" )
    {
        ?>
            <script>
                swal({
                    title: "Admin Already Existed , Please Check!",
                    icon: "warning",
                });
            </script>
        <?php
        unset($_SESSION['admin_alert_message'] );
    }
?>
<!--Admin existed Message-->
<?php
    if(isset($_SESSION['admin_alert_message']) && $_SESSION['admin_alert_message'] == "coursecodeexisted" )
    {
        ?>
            <script>
                swal({
                    title: "Admin Code Already Existed , Please Check!",
                    icon: "warning",
                });
            </script>
        <?php
        unset($_SESSION['admin_alert_message'] );
    }
?>
<!--Error Message-->
<?php
    if(isset($_SESSION['admin_alert_message']) && $_SESSION['admin_alert_message'] == "error" )
    {
        ?>
            <script>
                swal({
                    title: "Something went wrong",
                    text: "Please check!";
                    icon: "error",
                });
            </script>
        <?php
        unset($_SESSION['admin_alert_message'] );
    }
?>

<!--Data incomplete input Message-->
<?php
    if(isset($_SESSION['admin_alert_message']) && $_SESSION['admin_alert_message'] == "incomplete" )
    {
        ?>
            <script>
                swal(
                    title: "Please fill all the data field!",
                    icon: "warning",
                });
            </script>
        <?php
        unset($_SESSION['admin_alert_message'] );
    }
?>
<!-- ALERT MESSAGE-->
