 <!-- ALERT MESSAGE-->
 <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!--Added Succesfully Message-->
<?php
    if(isset($_SESSION['alert_message']) && $_SESSION['alert_message']  == "added" )
    {
        ?>
            <script>
                swal({
                    title: "College Department Successfully Added",
                    icon: "success",
                });
            </script>
        <?php
        unset($_SESSION['alert_message'] );
    }
?>
<!--Updated Succesfully Message-->
<?php
    if(isset($_SESSION['alert_message']) && $_SESSION['alert_message']  == "updated" )
    {
        ?>
            <script>
                swal({
                    title: "College Department Successfully Updated!",
                    icon: "success",
                });
            </script>
        <?php
        unset($_SESSION['alert_message'] );
    }
?>
<!--Delete Succesfully Message-->
<?php
    if(isset($_SESSION['alert_message']) && $_SESSION['alert_message']  == "deleted" )
    {
        ?>
            <script>
                swal(
                    title: "College Department Successfully Deleted!",
                    icon: "success",
                });
            </script>
        <?php
        unset($_SESSION['alert_message'] );
    }
?>
<!--Nothing Change Message in updating data-->
<?php
    if(isset($_SESSION['alert_message']) && $_SESSION['alert_message']  == "deleted" )
    {
        ?>
            <script>
                swal({
                    title: "College Successfuly Deleted!",
                    icon: "warning",
                });
            </script>
        <?php
        unset($_SESSION['alert_message'] );
    }
?>
<!--Warning Message-->
<?php
    if(isset($_SESSION['alert_message']) && $_SESSION['alert_message']  == "collegeexisted" )
    {
        ?>
            <script>
                swal({
                    title: "College Already Existed , Please Check!",
                    icon: "warning",
                });
            </script>
        <?php
        unset($_SESSION['alert_message'] );
    }
?>
<?php
    if(isset($_SESSION['alert_message']) && $_SESSION['alert_message']  == "collegecodeexisted" )
    {
        ?>
            <script>
                swal({
                    title: "College Code Already Existed , Please Check!",
                    icon: "warning",
                });
            </script>
        <?php
        unset($_SESSION['alert_message'] );
    }
?>
<?php
    if(isset($_SESSION['alert_message']) && $_SESSION['alert_message']  == "sealexisted" )
    {
        ?>
            <script>
                swal({
                    title: "Seal Already Existed or Added , Please Check!",
                    icon: "warning",
                });
            </script>
        <?php
        unset($_SESSION['alert_message'] );
    }
?>
<?php
    if(isset($_SESSION['alert_message']) && $_SESSION['alert_message']  == "unchanged" )
    {
        ?>
            <script>
                swal({
                    title: "nothing has been changed or updated",
                    icon: "warning",
                });
            </script>
        <?php
        unset($_SESSION['alert_message'] );
    }
?>

<!--Error Message-->
<?php
    if(isset($_SESSION['alert_message']) && $_SESSION['alert_message']  == "error" )
    {
        ?>
            <script>
                swal({
                    title: "Something went wrong",
                    text: "Please check!";
                    icon: "error",
                });
            </script>
        <?php
        unset($_SESSION['alert_message'] );
    }
?>
<!-- ALERT MESSAGE-->
