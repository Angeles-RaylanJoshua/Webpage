 <!-- ALERT MESSAGE-->
 <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

<!--Added Succesfully Message-->
<?php
    if(isset($_SESSION['request_alert_message']) && $_SESSION['request_alert_message'] == "added" )
    {
        ?>
            <script>
                swal({
                    title: "Subject Successfully Submitted , Just wait for the response!",
                    icon: "success",
                });
            </script>
        <?php
        unset($_SESSION['request_alert_message'] );
    }
?>