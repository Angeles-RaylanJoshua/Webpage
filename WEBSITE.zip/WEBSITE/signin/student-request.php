<?php
	include("../includes/config.php");

	$query1 = mysqli_query($connection, "SELECT * FROM	tblcollege ");

	while($co = mysqli_fetch_array($query1)){
		$getcolid = $co['id'];
		$getcollege = $co['college'];
	}

	$query2 = mysqli_query($connection, "SELECT * FROM tblcourse WHERE collegeid_fk='$getcollege'");
	while($cour = mysqli_fetch_array($query2)){
		$getcurid = $cour['id'];
		$getcourse = $cour['course'];
	}

?>
<!DOCTYPE html>
<html>
	<head>
		<!--Let browser know website is optimized for mobile-->
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<!-- BOOTSTRAP -->
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous" />
		<link rel="stylesheet" href="../bootstrap/bootstrap.min.css" />
		<!-- fontawesome -->
		<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
		<!-- local css -->
		<link rel="stylesheet" href="../css/request.css" />
		<title>Request Account</title>
	</head>

	<body>
		<!-- CONTAINER NO MARGIN -->
		<div class="bg overflow-hidden">
			<!-- CONTAINER WITH MARGIN -->
			<div class="container mt-5">
				<!-- PARENT -->
				<div class="row">
					<!--CHILD LEFT -->
					<div class="col-6" id="left-side">
						<form id="student-request-form" class="p-3" action="" onsubmit ="return checkForm(this);" method="POST">
						<div id="error_msg"></div>
						<!--condition mesage for existing error_msg -->
						
						<!-- HEADING -->
							<div class="title mb-5">
								<h3 class="mb-4">
									Student Request Form
									<span>
										<a class="role" id="active" href="#"><i class="fas fa-user-graduate"></i></a>
										<a class="role" href="staff-request.php"><i class="fas fa-user-tie"></i></a>
									</span>
								</h3>
							</div>
							<!-- HEADING END -->

							<!-- INPUT FIELDS -->
					
							<!-- FIRSTNAME -->
							<div class="row mb-3">
								<label for="first-name" class="col-sm-4 col-form-label">First Name</label>
								<div class="col-sm-8">
									<input type="text" name="firstname" autocomplete="off" class="form-control" id="firstname" placeholder="Enter Firstname" required/>
								</div>
							</div>

							<!-- LASTNAME -->
							<div class="row mb-3">
								<label for="last-name" class="col-sm-4 col-form-label">Last Name</label>
								<div class="col-sm-8">
									<input type="text" name="lastname" autocomplete="off" class="form-control" id="lastname" placeholder="Enter Lastname" required />
								</div>
							</div>
							<div id="error_msg"></div>
							<!-- EMAIL -->
							<div class="row mb-3">
								<label for="email" class="col-sm-4 col-form-label">Email</label>
								<div class="col-sm-8">
									<input type="email" name="email" id="email" autocomplete="off" placeholder="@wmsu.edu.ph" class="form-control" placeholder="Enter Email" required>
									<span></span>
								</div>
							</div>

							<!-- PASSWORD -->
							<div class="row mb-3">
								<label for="pass" class="col-sm-4 col-form-label">Password</label>
								<div class="col-sm-8">
									<input type="password" name="password" class="form-control" id="password" placeholder="Enter Password" required />
								</div>
								
							</div>

							<div class="row mb-3">
								<label for="pass" class="col-sm-4 col-form-label">Confirm Password</label>
								<div class="col-sm-8">
									<input type="password" name="repeatpassword" onkeyup="checkPass(); return false;" class="form-control" id="pass2" placeholder="Enter Password" required />
									<div id="error-nwl"></div>
									<input type="checkbox" onclick="myFunction()">  Show Password
								</div>
							</div>
							
							<!-- DEPARTMENT -->
							<div class="row mb-3">
								<label for="department" class="col-sm-4 col-form-label">Department</label>
								<div class="col-sm-8">
									<input class="form-control" autocomplete="off" name="department" list="departments" id="department" placeholder="Select Department..."/>
									<datalist id="departments">
									<?php
										$sql2 = mysqli_query($connection, "SELECT * From tblcollege");  
										// Use select query 
			
										while($fa = mysqli_fetch_array($sql2))
										{
											$getIdCollege = $fa['id'];
											echo "<option>" . $fa['college'] ."</option>";  
											// displaying data in option menu
										}	
									?>  
									<input class="form-control" name="idcol" id="idcol" value="<?php echo $getIdCollege ?>" hidden/>
									</datalist>
								</div>
							</div>

							<div class="row mb-3">
								<label for="course" class="col-sm-4 col-form-label">Course</label>

								<!-- COURSE -->
								<div class="col-sm-4">
                                    <input class="form-control" autocomplete="off" name="course" list="course" id="department" placeholder="Course...">
                                    <datalist id="course">
                                    <?php
									
									$query = mysqli_query($connection, "SELECT * From tblcourse ");

									while($sa = mysqli_fetch_array($query))
									{
										$viewid = $sa['id'];
										echo "<option>" .$sa['course']."</option>";
									}
									?>     
									<input class="form-control" name="idcour" id="idcour" value="<?php echo $viewid ?>" hidden/> 
                                    </datalist>	
								</div>

								<!-- YEARLEVEL -->
								<div class="col-sm-4">
									<input class="form-control" name="year" list="year-levels" id="year" placeholder="Year Level" />
									<datalist id="year-levels">
										<option value="1"></option>
										<option value="2"></option>
										<option value="3"></option>
										<option value="4"></option>
										<option value="5"></option>
									</datalist>
								</div>
							</div>

							<!--STATUS-->
							<div class="row mb-3">
								<label for="status" class="col-sm-4 col-form-label">Status</label>
								<div class="col-sm-8">
									<input class="form-control" name="status" list="status-options" id="status" placeholder="Select Status" />
									<datalist id="status-options">
										<option value="Old Student"></option>
										<option value="New Student"></option>
									</datalist>
								</div>
							</div>
							<input class="form-control" name="usertype" value="Student" id="usertype" hidden/>

							<div class="row mb-3">
								<label for="last-name" class="col-sm-4 col-form-label">Adviser Email</label>
								<div class="col-sm-8">
									<input type="text" name="adviser" autocomplete="off" class="form-control" id="adviser" placeholder="Adviser Email" required />
								</div>
							</div>
							
							<!-- INPUT FIELDS END -->

							<!-- ACTION BUTTONS -->
							<div class="buttons">
								<a href="universal-signin.php" class="btn btn-secondary" id="back-btn">Back</a>
								<button type="submit" name="add" class="btn btn-danger" id="add">Submit</button>
							</div>
							<!-- ACTION BUTTONS END -->
						</form>
					</div>
					<!-- CHILD LEFT END -->

					<!-- CHILD RIGHT -->
					<div class="col-6" id="right-side">
						<div class="bg-circle"></div>
						<div class="containr">
							<img src="../images/request.svg" alt="" />
						</div>
					</div>
					<!-- CHILE RIGHT END -->
				</div>
				<!-- PARENT END -->
			</div>
			<!-- MARGIN WITH CONTAINER END -->
		</div>
		<!-- CONTAINER NO MARGIN END -->

		<!-- ONLINE BOOTSTRAP JS -->
		<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
		<!-- OFFLINE BOOTSTRAP JS -->
		<script src="../bootstrap/bootstrap.min.js"></script>
	<script>
    function myFunction() {
        var x = document.getElementById("password");
		var y = document.getElementById("pass2");
        if (x.type === "password" || y.type === "password") {
            x.type = "text";
			y.type = "text";
        } else {
            x.type = "password";
			y.type = "password";
        }
    }
	</script>
	
	<script>

	function checkForm(form)
	{

  	if(form.password.value != "" && form.password.value == form.repeatpassword.value) {
		if(form.password.value.length < 8) {
	  		alert("Error: Password must contain at least eight characters!");
	  		form.password.focus();
	  		return false;
		}
		re = /[0-9]/;
		if(!re.test(form.password.value)) {
	  		alert("Error: password must contain at least number (0-9)!");
	  		form.password.focus();
	  	return false;
		}
		re = /[a-z]/;
		if(!re.test(form.password.value)) {
	  		alert("Error: password must contain at least lowercase letter (a-z)!");
	  		form.password.focus();
	  	return false;
		}
		re = /[A-Z]/;
		if(!re.test(form.password.value)) {
	  		alert("Error: password must contain at least uppercase letter (A-Z)!");
	  		form.password.focus();
	  	return false;
		}
		re = /[!@#$%^&*:;]/;
  		if(!re.test(form.password.value)) {
			alert("Error: password must contain at least characters!");
			form.password.focus();
		return false;
  	}
  	} else {
			alert("Error: Please check that you've entered and confirmed your password!");
			form.password.focus();
		return false;
  	}

  	
  	return true;
	}
	</script>
	<script src="jquery-3.2.1.min.js"></script>
    <script src="script.js"></script>
    <script>
		$('document').ready(function(){
        var email_state = false;
		$('#studid').on('blur', function(){
        var studid = $('#studid').val();
        if (studid == '') {
  	        student_state = false;
  	        return;
        }
        $.ajax({
        url: 'reg-Student.php',
        type: 'post',
        data: {
    	    'student_check' : 1,
    	    'studid' : studid,
        },
        success: function(response){
        if (response == 'taken' ) {
      	    student_state = false;
      	    $('#studid').parent().removeClass();
      	    $('#studid').parent().addClass("form_error");
      	    $('#studid').siblings("span").text('Sorry... StudentID already taken');
        }else if (response == 'not_taken') {
      	    student_state = true;
      	    $('#studid').parent().removeClass();
      	    $('#studid').parent().addClass("form_success");
      	    $('#studid').siblings("span").text('StudentID available');
            }
            }
            });
        });		
		// condition for error email	
        $('#email').on('blur', function(){
 	    var email = $('#email').val();
 	    if (email == '') {
 		    email_state = false;
 		    return;
 	    }
 	    $.ajax({
        url: 'reg-Student.php',
        type: 'post',
        data: {
      	    'email_check' : 2,
            'email' : email,
        },
        success: function(response){
      	if (response == 'taken' ) {
            email_state = false;
            $('#email').parent().removeClass();
            $('#email').parent().addClass("form_error");
            $('#email').siblings("span").text('Sorry... Email already taken');
      	}else if (response == 'not_taken') {
      	    email_state = true;
      	    $('#email').parent().removeClass();
      	    $('#email').parent().addClass("form_success");
      	    $('#email').siblings("span").text('Email available');
      	    }
            }
 	    });
        });
		// submit the value where submit button = id=add: then selecting in name and id in input text
        $('#add').on('click', function(){
 	    var email = $('#email').val();
 	    var password = $('#password').val();
        var firstname = $('#firstname').val();
        var lastname = $('#lastname').val();
        var idcour = $('#idcour').val();
        var year = $('#year').val();
        var idcol = $('#idcol').val();
		var adviser = $('#adviser').val();
		var status = $('#status').val();
		var usertype = $('#usertype').val();
 	    if (email_state == false) {
	    $('#error_msg').text('Fix the errors in the form first');
	    }else{
        // proceed with form submission selecting in name and id in input text
        $.ajax({
      	    url: 'reg-Student.php',
      	    type: 'post',
      	    data: {
      		    'save' : 1,
      		    'email' : email,
      		    'status' : status,
      		    'password' : password,
                'firstname' : firstname,
      		    'lastname' : lastname,
      		    'idcour' : idcour,
                'year' : year,
      		    'idcol' : idcol,
				'adviser' : adviser,
				'usertype' : usertype,
      	    },
      	    success: function(response){
      		    alert('user saved');
      		    $('#firstname').val('');
      		    $('#email').val('');
      		    $('#password').val('');
                $('#lastname').val('');
      		    $('#adviser').val('');
      		    $('#idcour').val('');
                $('#year').val('');
      		    $('#idcol').val('');
				$('#status').val('');
				$('#usertype').val('');
      	        }
            });
        }
        });
	});
});	
    </script>

	</body>
</html>
