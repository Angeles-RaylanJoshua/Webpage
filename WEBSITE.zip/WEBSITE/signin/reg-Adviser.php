<?php
	include "../includes/config.php";

	if (isset($_POST['submit-request']))
	{
			$firstname = mysqli_real_escape_string($connection,$_POST['firstname']);
			$lastname = mysqli_real_escape_string($connection,$_POST['lastname']);
			$email = mysqli_real_escape_string($connection,$_POST['email']);
			$password = mysqli_real_escape_string($connection,$_POST['password']);
			$usertype = mysqli_real_escape_string($connection,$_POST['status']);
			$department = mysqli_real_escape_string($connection,$_POST['department']);
			$course = mysqli_real_escape_string($connection,$_POST['course']);
			$yearlevel = mysqli_real_escape_string($connection,$_POST['year']);
			$name = $firstname." ".$lastname;
			//detect course
			$sqldetect2 = "SELECT * FROM tblcourse WHERE course='$course'";

			$myData = mysqli_query($connection,$sqldetect2);
			while($record = mysqli_fetch_array($myData)) { 
				$courseid = $record['id'];
			}

			$sql_a = "INSERT INTO `tblrequest_account`(`course_id_fk`, `email`, `password`, `usertype`, `firstname`, `lastname`, `yearlevel`) VALUES ($courseid, '$email','$password','$usertype','$firstname', '$lastname','$yearlevel')";
		
            if(mysqli_query($connection,$sql_a)){
				$_SESSION['request_alert_message'] = "added";
				header("location: staff-request.php");
			}
            else{
                echo "ERROR:Could not be able to execute $sql_a. " .mysqli_error($connection);    
			}  	
	}
?>