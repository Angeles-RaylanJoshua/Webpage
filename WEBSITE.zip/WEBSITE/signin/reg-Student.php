<?php
	include "../includes/config.php";

		if (isset($_POST['email_check'])) {
			$email = $_POST['email'];
			$sqle = "SELECT * FROM tblusers WHERE email='$email'";
			$resulti = mysqli_query($connection, $sqle);
			if (mysqli_num_rows($resulti) > 0) {
			  echo 'taken';	
			}else{
			  echo 'not_taken';
			}
			exit();
		}

		if (isset($_POST['save']))
		{
			$firstname = mysqli_real_escape_string($connection,$_POST['firstname']);
			$lastname = mysqli_real_escape_string($connection,$_POST['lastname']);
			$Email = mysqli_real_escape_string($connection,$_POST['email']);
			$password = mysqli_real_escape_string($connection,$_POST['password']);
			$idcol = mysqli_real_escape_string($connection,$_POST['idcol']);
			$idcour = mysqli_real_escape_string($connection,$_POST['idcour']);
			$year = mysqli_real_escape_string($connection,$_POST['year']);
			$per_status = mysqli_real_escape_string($connection,$_POST['status']);
			$usertype = mysqli_real_escape_string($connection,$_POST['usertype']);
			$status = '0';
			$iparr = explode ("@",$Email,2);
			$Emailed = $iparr[0];

			$sqli = "SELECT * FROM email tblusers WHERE email='$Email'";
  	        $results = mysqli_query($connection, $sqli);
  	        if (mysqli_num_rows($results) > 0) {
  	            echo "exists";	
  	            exit();
            }else{

			$sql_e="INSERT INTO tblusers (college_id_fk,email,password,usertype,uniId,firstname,lastname,status,per_status,courseid_fk,yearlevel )VALUES('$idcol','$Email','$password','$usertype','$Emailed','$firstname','$lastname','$status','$per_status','$idcour','$year')";
		
			$results=mysqli_query($connection,$sql_e);
				echo 'Saved!';     
				header("location:student-request.php");
			exit(); 
			}
        }
		if (isset($_POST['save']))
		{
			$firstname = mysqli_real_escape_string($connection,$_POST['firstname']);
			$lastname = mysqli_real_escape_string($connection,$_POST['lastname']);
			$emails = mysqli_real_escape_string($connection,$_POST['email']);
			$password = mysqli_real_escape_string($connection,$_POST['password']);
			$idcol = mysqli_real_escape_string($connection,$_POST['idcol']);
			$idcour = mysqli_real_escape_string($connection,$_POST['idcour']);
			$year = mysqli_real_escape_string($connection,$_POST['year']);
			$status = mysqli_real_escape_string($connection,$_POST['status']);
			$adviser = mysqli_real_escape_string($connection,$_POST['adviser']);

			$sqls = "SELECT * FROM email tblrequeststudent WHERE email='$emails'";
  	        $results = mysqli_query($connection, $sqls);
  	        if (mysqli_num_rows($results) > 0) {
  	            echo "exists";	
  	            exit();
            }else{

			$sql_s="INSERT INTO `tblrequeststudent`(`course_id_fk`, `email`,`password`,`firstname`, `lastname`, `status`, `yearlevel`,`college_id_fk`, `adviser`) VALUES ('$idcour','$emails','$password','$firstname','$lastname','$status','$year','$idcol','$adviser')";
		
			$results=mysqli_query($connection,$query_s);
				echo 'Saved!';     
				header("location:student-request.php");
			exit(); 
			}
        }
	mysqli_close($connection);
?>