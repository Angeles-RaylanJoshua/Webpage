<?php
   session_start();
   include("../includes/config.php");
   
   if($_SERVER["REQUEST_METHOD"] == "POST"){
      // email and password sent from form 
      
      $myemail = mysqli_real_escape_string($connection,$_POST['email']);
      $mypassword = mysqli_real_escape_string($connection,$_POST['password']);
   
      
      $sql = "SELECT * FROM tblusers WHERE email = '$myemail' and password = '$mypassword' and status = '1'";
      $result = mysqli_query($connection,$sql);


      
      // If result matched $myemail and $mypassword, table row must be 1 row
		
      if(mysqli_num_rows($result) == 1){

      	$con = mysqli_fetch_array($result);

         $_SESSION['login_user'] = $myemail;
         $_SESSION['id'] = $con['id'];
         $_SESSION['usertype'] = $con['usertype'];
         $_SESSION['email'] = $con['email'];
         $_SESSION['password'] = $con['password'];
         $_SESSION['college_id_fk'] = $con['college_id_fk'];
         $_SESSION['courseid_fk'] = $con['courseid_fk'];
         $_SESSION['yearlevel'] = $con['yearlevel'];
         $_SESSION['login_message'] = "success";

         if($con['usertype'] == "Superadmin"){
            header("refresh: 0; url= ../users/SuperAdmin/superadmin-homepage.php");
         }else if($con['usertype'] == "Admin"){
         	header("refresh: 0; url= ../users/Admin/admin-homepage.php");
         }else if($con['usertype'] == "Adviser"){
            header("refresh: 0; url= ../users/Adviser/adviser-homepage.php");
         }else if($con['usertype'] == "Student"){
         	header("refresh: 0; url= ../users/Student/student-i.php");
         }

      }
      else 
      {
         $_SESSION['login_message'] = "error";      
         header("refresh: 0; url= ../signin/universal-signin.php");
      }
   }
?>