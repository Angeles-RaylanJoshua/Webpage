<?php
	session_start();
	include("../includes/config.php"); 
	include("../includes/requestalertmessage.php"); 
?>
<!DOCTYPE html>
<html>
	<head>
		<!--Let browser know website is optimized for mobile-->
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<!-- BOOTSTRAP -->
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous" />
		<link rel="stylesheet" href="../bootstrap/bootstrap.min.css" />
		<!-- fontawesome -->
		<link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
		<!-- local css -->
		<link rel="stylesheet" href="../css/request.css" />
		<title>Request Account</title>
	</head>

	<body>
		<!-- CONTAINER NO MARGIN -->
		<div class="bg overflow-hidden">
			<!-- CONTAINER WITH MARGIN -->
			<div class="container mt-5">
				<!-- PARENT -->
				<div class="row">
					<!--CHILD LEFT -->
					<div class="col-6" id="left-side">
						<form id="staff-request-form" class="p-3" action="" onsubmit ="return checkForm(this);" method="POST">
							<!-- HEADING FOR STAFF  REQUEST FORM -->
							<div class="title mb-5">
								<h3 class="mb-4">
									Staff Request Form
									<span>
										<a class="role" href="student-request.php"><i class="fas fa-user-graduate"></i></a>
										<a class="role" id="active" href="#"><i class="fas fa-user-tie"></i></a>
									</span>
								</h3>
							</div>
							<!-- HEADING END -->

							<!-- INPUT FIELDS -->

							<!-- FIRSTNAME -->
							<div class="row mb-3">
								<label for="first-name" class="col-sm-4 col-form-label">First Name</label>
								<div class="col-sm-8">
									<input type="text" name="firstname" class="form-control" id="first-name" placeholder="Enter Firstname" required/>
								</div>
							</div>

							<!-- LASTNAME -->
							<div class="row mb-3">
								<label for="last-name" class="col-sm-4 col-form-label">Last Name</label>
								<div class="col-sm-8">
									<input type="text" name="lastname" class="form-control" id="last-name" placeholder="Enter Lastname" required />
								</div>
							</div>

							<!-- EMAIL -->
							<div class="row mb-3">
								<label for="#email" class="col-sm-4 col-form-label">Email</label>
								<div class="col-sm-8">
									<input type="email" aname="email" placeholder="@wmsu.edu.ph" class="form-control" id="email" placeholder="Enter Email" required/>
								</div>
							</div>

							<!-- PASSWORD -->
							<div class="row mb-3">
								<label for="pass" class="col-sm-4 col-form-label">Password</label>
								<div class="col-sm-8">
									<input type="password" name="password"  class="form-control" id="pass1" placeholder="Enter Password" required />
									
								</div>
							</div>
							<div class="row mb-3">
								<label for="pass" class="col-sm-4 col-form-label">Confirm Password</label>
								<div class="col-sm-8">
									<input type="password" name="repeatpassword" onkeyup="checkPass(); return false;" class="form-control" id="pass2" placeholder="Enter Password" required />
									<div id="error-nwl"></div>
									<input type="checkbox" onclick="myFunction()">  Show Password
								</div>
							</div>

							
							<!-- DEPARTMENT -->
							<div class="row mb-3">
								<label for="department" class="col-sm-4 col-form-label">Department</label>
								<div class="col-sm-8">
									<input class="form-control" name="department" list="departments" id="department" placeholder="Select Department..."/>
									<datalist id="departments">
									<?php
										$sql2 = mysqli_query($connection, "SELECT * From tblcollege");  
										// Use select query 
			
										while($fa = mysqli_fetch_array($sql2))
										{
											echo "<option>" . $fa['college'] ."</option>";  
											// displaying data in option menu
										}	
									?>  
									</datalist>
								</div>
							</div>

							<!--STATUS-->
							<div class="row mb-3">
								<label for="status" class="col-sm-4 col-form-label">Status</label>
								<div class="col-sm-8">
									<input class="form-control" name="status" id="status" value="Adviser" readonly/>
								</div>
							</div>
							
							<!--If selected status is Adviser Course and Year input field will appear-->
							<script>
								
							</script>

							<div class="row mb-3">
								<label for="course" class="col-sm-4 col-form-label">Assigned to</label>

								<!-- COURSE -->
								<div class="col-sm-4">
									<input type="text" class="form-control" name="course" id="course" placeholder="Course" />						
								</div>

								<!-- YEARLEVEL -->
								<div class="col-sm-4">
									<input class="form-control" name="year" list="yearlevel" id="year" placeholder="Year Level" />
									<datalist id="year-levels">							
										<option value="1"></option>
										<option value="2"></option>
										<option value="3"></option>
										<option value="4"></option>
										<option value="5"></option>
									</datalist>
								</div>
							</div>

							<!-- INPUT FIELDS END -->

							<!-- ACTION BUTTONS -->
							<div class="buttons">
								<a href="universal-signin.php" class="btn btn-secondary" id="back-btn">Back</a>
								<button type="submit" name="submit-request" class="btn btn-danger" id="submit-btn">Submit</button>
							</div>
							<!-- ACTION BUTTONS END -->
						</form>
					</div>
					<!-- CHILD LEFT END -->

					<!-- CHILD RIGHT -->
					<div class="col-6" id="right-side">
						<div class="bg-circle"></div>
						<div class="containr">
							<img src="../images/request.svg" alt="" />
						</div>
					</div>
					<!-- CHILE RIGHT END -->
				</div>
				<!-- PARENT END -->
			</div>
			<!-- MARGIN WITH CONTAINER END -->
		</div>
		<!-- CONTAINER NO MARGIN END -->

		<!-- ONLINE BOOTSTRAP JS -->
		<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
		<!-- OFFLINE BOOTSTRAP JS -->
		<script src="../bootstrap/bootstrap.min.js"></script>
	
	<script>
    function myFunction() {
        var x = document.getElementById("pass1");
		var y = document.getElementById("pass2");
        if (x.type === "password" || y.type === "password") {
            x.type = "text";
			y.type = "text";
        } else {
            x.type = "password";
			y.type = "password";
        }
    }
	</script>
	<script>

	function checkForm(form)
	{

  	if(form.password.value != "" && form.password.value == form.repeatpassword.value) {
		if(form.password.value.length < 8) {
	  		alert("Error: Password must contain at least eight characters!");
	  		form.password.focus();
	  		return false;
		}
		re = /[0-9]/;
		if(!re.test(form.password.value)) {
	  		alert("Error: password must contain at least number (0-9)!");
	  		form.password.focus();
	  	return false;
		}
		re = /[a-z]/;
		if(!re.test(form.password.value)) {
	  		alert("Error: password must contain at least lowercase letter (a-z)!");
	  		form.password.focus();
	  	return false;
		}
		re = /[A-Z]/;
		if(!re.test(form.password.value)) {
	  		alert("Error: password must contain at least uppercase letter (A-Z)!");
	  		form.password.focus();
	  	return false;
		}
		re = /[!@#$%^&*:;]/;
  		if(!re.test(form.password.value)) {
			alert("Error: password must contain at least characters!");
			form.password.focus();
		return false;
  	}
  	} else {
			alert("Error: Please check that you've entered and confirmed your password!");
			form.password.focus();
		return false;
  	}

  	alert("You entered a valid password");
  	return true;
	}
	</script>
	</body>
</html>
