<?php
    session_start();
    include("../../includes/config.php");

    if (isset($_POST['add']))
    {
        $Firstname=mysqli_real_escape_string($connection,$_POST['firstname']);$Lastname=mysqli_real_escape_string($connection,$_POST['lastname']);
        $Email=mysqli_real_escape_string($connection,$_POST['email']);
        $Password=mysqli_real_escape_string($connection,$_POST['password']);
        $Usertype=mysqli_real_escape_string($connection,$_POST['usertype']);
        $CollegeID=mysqli_real_escape_string($connection,$_POST['college']);
        $status = 1;
        $assigned = 1;
        //insert data
        $sql="INSERT INTO tblusers (firstname,lastname,email,password,usertype,status,college_id_fk,already_assigned)VALUES('$Firstname','$Lastname','$Email','$Password','$Usertype','$status','$CollegeID',$assigned)";

        //update college as already assigned to an admin
        $updatecollege =mysqli_query($connection,"UPDATE tblcollege SET admin_exist = 1 WHERE id=$CollegeID");

        if(mysqli_query($connection,$sql))
        {
            $_SESSION['admin_alert_message'] = "added";
            header("location:superadmin-admins.php");
        }
        else
        {
            echo "ERROR:Could not be able to execute $sql. " .mysqli_error($connection);
        }
    }
    else if (isset($_POST['update'])){
                    
        $AdminID=mysqli_real_escape_string($connection,$_POST['id']);
        $Firstname=mysqli_real_escape_string($connection,$_POST['firstname']);$Lastname=mysqli_real_escape_string($connection,$_POST['lastname']);
        $Email=mysqli_real_escape_string($connection,$_POST['email']);
        $Password=mysqli_real_escape_string($connection,$_POST['password']);
        $CollegeID=mysqli_real_escape_string($connection,$_POST['college']);

        // Attempt update query execution
        $sql = "UPDATE tblusers SET firstname='$Firstname',lastname='$Lastname',email='$Email',password='$Password',college=$CollegeID WHERE id='$AdminID'";
            
        if(mysqli_query($connection, $sql)){
            // $_SESSION['admin_alert_message'] = "updated";
            // header("location:superadmin-admins.php");
            echo "buang";
        } else {
            echo "ERROR: Could not able to execute $sql. " .mysqli_error($connection);
        }
    }
    else if (isset($_POST['delete_admin']))
    {
        $id=$_POST['id'];

        $select_college = "SELECT * FROM tblusers WHERE id=$id";
        $select_college_run = mysqli_query($connection , $select_college);
        
        
		foreach($select_college_run as $fa_row)
		{
			$getcollegeid = $fa_row['college_id_fk'];
		}

        //update college as already assigned to an admin when admin is deleted
        $updatecollege =mysqli_query($connection,"UPDATE tblcollege SET admin_exist=0 WHERE id= '$getcollegeid'");

        echo $getcollegeid;
        $query="DELETE FROM tblusers WHERE id='$id'";

        if(mysqli_query($connection, $query)){
            $_SESSION['admin_alert_message'] = "deleted";
            header("location:superadmin-admins.php"); 
        } else {
            $_SESSION['admin_alert_message'] = "error";
        }
    }
	mysqli_close($connection);
?>