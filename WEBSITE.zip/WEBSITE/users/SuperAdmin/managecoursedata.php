<?php
    session_start();
	include("../../includes/config.php");

	if (isset($_POST['addcourse']))
	{
		$CourseID=mysqli_real_escape_string($connection,$_POST['id']);
		$CourseCode=mysqli_real_escape_string($connection,$_POST['coursecode']);
		$CourseName=mysqli_real_escape_string($connection,$_POST['course']);
		$Yearlevels=mysqli_real_escape_string($connection,$_POST['yearlevels']);
		$CollegeID=mysqli_real_escape_string($connection,$_POST['college']);

		$check_coursename="SELECT * FROM tblcourse WHERE course='$CourseName'";
		$check_coursecode="SELECT * FROM tblcourse WHERE coursecode='$CourseCode'";

		$check_coursename_run = mysqli_query($connection,$check_coursename);
		$check_coursecode_run = mysqli_query($connection,$check_coursecode);

		if(mysqli_num_rows($check_coursename_run) > 0)
		{
			$_SESSION['course_alert_message'] = "courseexisted";
			header("location:superadmin-courses.php");
		}
		else if(mysqli_num_rows($check_coursecode_run) > 0)
		{
			$_SESSION['course_alert_message'] = "coursecodeexisted";
			header("location:superadmin-courses.php");
		}
		else
		{
			if($Yearlevels == "Select Year Levels..." || $CollegeID == "Select College..." || $Yearlevels == "" || $CollegeID == "")
			{
				$_SESSION['course_alert_message'] = "added";
				header("location:superadmin-courses.php");
			}
			else{
				$sql="INSERT INTO tblcourse (id,coursecode,course,yearlevels,collegeid_fk)
				VALUES('$CourseID','$CourseCode','$CourseName',$Yearlevels,'$CollegeID')";
					
				if(mysqli_query($connection,$sql))
				{
					$_SESSION['course_alert_message'] = "added";
					header("location:superadmin-courses.php");
				}
				else
				{
					$_SESSION['course_alert_message'] = "error";
					header("location:superadmin-courses.php");
				}
		    }
		}
	}
	else if (isset($_POST['updatecourse'])){
		
		$CourseID=mysqli_real_escape_string($connection,$_POST['id']);
		$CourseCode=mysqli_real_escape_string($connection,$_POST['coursecode']);
		$CourseName=mysqli_real_escape_string($connection,$_POST['course']);
		$Yearlevels=mysqli_real_escape_string($connection,$_POST['yearlevels']);
		$CollegeID=mysqli_real_escape_string($connection,$_POST['collegeid']);

		if($Yearlevels == "" || $CollegeID == ""){
			//$_SESSION['course_alert_message'] = "incomplete";
			echo "buang ";
			//header("location:superadmin-courses.php");
		}
		else{
			// Attempt update query execution
			$sql = "UPDATE tblcourse SET coursecode='$CourseCode',course='$CourseName',yearlevels='$Yearlevels',collegeid_fk='$CollegeID' WHERE id='$CourseID'";
			
			if(mysqli_query($connection, $sql)){
				$_SESSION['course_alert_message'] = "updated";
				header("location:superadmin-courses.php");
			} else {
				$_SESSION['course_alert_message'] = "error";
				header("location:superadmin-courses.php");
			}
		}
	}
	else if (isset($_POST['delete']))
	{
		$id=$_POST['id'];

		$sql="DELETE FROM tblcourse WHERE id='$id'";
		
		if(mysqli_query($connection, $sql))
		{
			$_SESSION['course_alert_message'] = "deleted";
			header("location:superadmin-courses.php");
		} else {
			echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
		}
	}
	mysqli_close($connection); 
?>

