<?php
     include "../../includes/config.php";
     include('../../includes/userchecking.php');
    

    $email = $_SESSION['email'];
    
    if(isset($_POST['submit'])){
        //path to store the profile img
        $target = "../../profile/image/".basename($_FILES['image']['name']);
        
        $image=$_FILES['image']['name'];
        
        $sql = "UPDATE tblusers SET picture='$image' WHERE email = '$email'";

        //move uploaded profile to the folder
        if(move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
            echo "Profile Picture uploaded successfully..";
            mysqli_query($connection, $sql);
            header("location: ../Adviser/adviser-myprofile.php");
        }
        else 
            echo "There was a problem uploading the profile picture.";
    }
    
?>