 <!-- LOGOUT MODAL-->
 <?php
//update//

$email = $_SESSION['email'];

$sql = "SELECT * usertype='Adviser' FROM tblusers";

$result = mysqli_query($connection,$sql);
if($connection === false){
            die("ERROR: Could not connect. " .mysqli_connect_error());
        }
        else{
            if (isset($_POST['updates']))
            {
                $password=$_POST['password'];
    
                $query="UPDATE tblusers SET password='$password' WHERE email='$email'";
 
            if(mysqli_query($connection, $query)){
                
            }else{
                echo "an error occured".$connection->error;
        }
    }
}
?>
<?php
        $email = $_SESSION['email'];
        $getdata=mysqli_query($connection,"SELECT * FROM tblusers WHERE email='$email'");

        while($data=mysqli_fetch_array($getdata))
        {
            $email = $data['email'];
            $firstname = $data['firstname'];
            $lastname = $data['lastname'];
            $contact = $data['contact'];
            $password = $data['password'];
        }   
?>

 <div class="container container-fluid">
        <div class="modal fade" id="changemodal" tabindex="-1" aria-labelledby="logoutmodalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <center>
                        <div class="modal-body">
                        <form action="" method="POST">
                        Change Password
                        <div class="col-md-6">
                         
                            <input type="hidden" name="firstname" class="form-control" id="first" value="<?php echo ucfirst($firstname)?>" readonly>
                        </div>
                        <div class="col-md-6">
                  
                            <input type="hidden" name="lastname" class="form-control" id="last" value="<?php echo ucfirst($lastname)?>" readonly>
                        </div>
                        <!-- second line -->
                        <div class="col-md-12">
                    
                            <input type="hidden" name="email" class="form-control" id="empID" value="<?php echo $email?>" readonly>
                        </div>
                        
                        <!-- third line -->
                        <div class="col-md-12">
                    
                            <input type="hidden" name="email" class="form-control" id="email" value="<?php echo $email?>"  readonly>
                        </div>
                       
                        <!-- fourth line -->
                        <div class="col-md-12">
                         
                            <input type="hidden" name="contact" class="form-control" onkeyup='check();' id="Contact" value="<?php echo $contact?>" required>
                        </div>
                        <div>
                            <input type="password" name="password" class="form-control" id="Password" value="<?php echo $password?>" required>                          
                        </div>
                        <div>
                            <input type="checkbox" onclick="myFunction()">Show Password
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                            <button type="submit" href="../Adviser/adviser-myprofile.php" name="updates" class="btn btn-danger">Yes</button>
                        </div> 
                        </form>                    
                    </center>
                </div>
            </div>
        </div>
    </div>

<script>
function myFunction() {
    if (document.getElementById('password').value ==
    document.getElementById('confirm_password').value) {
    document.getElementById('message').style.color = 'green';
    document.getElementById('message').innerHTML = 'matching';
  } else {
    document.getElementById('message').style.color = 'red';
    document.getElementById('message').innerHTML = 'matching';
  }
}
</script>
<script>
    function myFunction() {
  var x = document.getElementById("Password");
  if (x.type === "password") {
    x.type = "text";
  } else {
    x.type = "password";
  }
}
</script>
<!--END OF LOGOUT MODAL-->