<?php
	session_start();
	include("../../includes/logout.php");
    include("../../includes/config.php");
     
    $user_check = $_SESSION['login_user'];
    $user_col = $_SESSION['college_id_fk'];
	$query1 = mysqli_query($connection, "SELECT * FROM tblusers WHERE email = '$user_check'");
    while($fa = mysqli_fetch_array($query1))
    {
		$detectedfirst = $fa['firstname'];
		$detectedlast = $fa['lastname'];
		$detectedfull = ucfirst($detectedfirst).' '.ucfirst($detectedlast);
        $detected = $fa['college_id_fk'];
        $cour = $fa['courseid_fk'];
        $detectedyear = $fa['yearlevel'];
    }

    $query2 = mysqli_query($connection, "SELECT * FROM tblcourse WHERE collegeid_fk = '$detected'");
    while($fa = mysqli_fetch_array($query2))
    {
        $detectedcourseid = $fa['id'];
        $detectedcourse = $fa['course'];
        $detectedyear = $fa['yearlevels'];
    }

    $query3 = mysqli_query($connection, "SELECT * FROM tblsections");
    while($sa = mysqli_fetch_array($query3))
    {
        $detectedsecid = $sa['id'];
        $detectedseccode = $sa['sectioncode'];
        $detectedsecname = $sa['section_name'];
        $detectedsecAvail = $sa['available_slots'];
        $detectedsecNum = $sa['number_of_students'];
        $detectedTotal = $detectedsecAvail - $detectedsecNum;
        $detectedseccol = $sa['college'];
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- BOOTSTRAP -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous" />
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/dataTables.bootstrap4.css" />
    <!-- OFFLINE BOOTSTRAP -->
    <link rel="stylesheet" href="../../bootstrap/bootstrap.min.css" />

    <!-- fontawesome -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <link rel="stylesheet" href="../../bootstrap/fontawesome.min.css">
    <!-- local css -->
    <link rel="stylesheet" href="../../css/style-adviser.css" />

    <title>Student Grade Submission</title>
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-dark" id="navbar">
        <div class="container-fluid">
            <!-- ICS LOGO -->
            <a class="navbar-brand p-0 m-0" href="#" id="nav-logo">
            <?php 
                    $user_check = $_SESSION['login_user'];
                    $query1 = mysqli_query($connection, "SELECT * FROM tblusers WHERE email = '$user_check'");
						while($getcollege = mysqli_fetch_array($query1))
						{ 
							$college_check = $getcollege['college_id_fk'];
							$getdata = mysqli_query($connection,"SELECT * FROM tblcollege WHERE id='$college_check'");

							while($fa = mysqli_fetch_array($getdata))
							{
								$boom = $fa['seal'];
								echo "<span id='department'>  "."<img style='width: 2rem; height: 2rem; margin-right: 10px;' src='../SuperAdmin/images/$boom'>".$fa['college']."</span>";
							}
						}							
					?> 
            </a>

            <!-- MOBILE TOGGLE -->
            <button class="navbar-toggler m-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span><i class="fas fa-bars"></i></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav">
                    <!-- Profile -->
                    <li class="nav-item">
                        <a class="nav-link active py-0" aria-current="page" href="adviser-myprofile.php"><i id="icons" class="fas fa-user-tie"></i><span class="nav-label"> My Profile</span></a>
                    </li>
                    <!-- Home -->
                    <li class="nav-item">
                        <a class="nav-link active py-0" aria-current="page" href="adviser-homepage.php"><i id="icons" class="fas fa-home"></i><span class="nav-label"> Home</span></a>
                    </li>
                    <!-- notifications -->
                    <li class="nav-item dropstart">
                        <a class="nav-link dropstart active py-0" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false"> <i id="icons" class="fas fa-bell"></i><span class="badge rounded-pill bg-info text-white align-text-top" id="notif-number">3</span><span class="nav-label"> Notifications</span> </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li>
                                <a data-bs-toggle="modal" data-bs-target="#manage-request" class="dropdown-item" href="#">
                                    <span class="badge bg-success">Account</span>
                                    Student requested an account
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="adviser-view-grades.php">
                                    <span class="badge bg-primary">Grade</span>
                                    <span class="text fw-bold">Brigole</span> submitted his grade
                                </a>
                            </li>
                            <li>
                                <a class="dropdown-item" href="adviser-view-grades.php">
                                    <span class="badge bg-primary">Grade</span>
                                    <span class="text fw-bold">Colao</span> submitted her grade
                                </a>
                            </li>
                            <!-- <li><hr class="dropdown-divider" /></li> -->
                            
                        </ul>
                    </li>
                    <!-- logout -->
                    <li class="nav-item">
							<a type="button" id="icons" class="nav-link active py-0" data-bs-toggle="modal" data-bs-target="#logoutmodal" aria-disabled="true"><i class="fas fa-sign-out-alt"></i><span class="nav-label"> Logout</span></a>
					</li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- END OF NAVBAR -->
    <?php 
        $select = mysqli_query($connection, "SELECT * FROM tblsub_grades");

        while($pe = mysqli_fetch_array($select))
        {
            $getid = $pe['id'];
            $getemail =$pe['student_email'];
        }
    ?>
    
    <!-- CONTENT  -->
    <div class="container mt-3 mb-3 container-fluid">
        <!-- left side -->
        <form action="managegradesubmissions.php" method="POST">
            <div class="row ">
                <div class="col">
                    <div class="container">
                        <p class="text text-danger text-center fw-bold fs-2"> Student's Name <span class="text fw-normal">Grade</span></p>
                    </div>
                    <table class="table table-responsive table-bordered table-striped table-hover text-white mt-4 mb-3" id="tableStudentGrade">
                        <thead>
                            <th hidden><center>Id</center></th>
                            <th><center>Email</center></th>
                            <th><center>Subject Code</center></th>
                            <th><center>Grades</center></th>
                            
                        </thead>
                        <tbody class="table-light">
                        <?php

                        $dissub = mysqli_query($connection, "SELECT * FROM tblsub_grades WHERE student_email='$getemail' and courseid_fk='$detectedcourseid' and yearlevel='$detectedyear'");
                
                        while($dis = mysqli_fetch_array($dissub))
                        {         
                            $Getid = $dis['id'];
                            $Getemail = $dis['student_email'];
                            echo "<tr>";
                            echo "<td hidden><center>".$Getid."</center></td>";
                            echo "<td><center>".$Getemail."</center></td>";
                            echo "<td><center>".$dis['subject_code']."</center></td>";
                            echo "<td><center>".$dis['grades']."</center></td>";
                            echo "</tr>";                                       
                        }
                        ?>                       
                        </tbody>
                    </table>
                </div>

                <!--   right side   -->
                <div class="col-sm-3">
                    <div class="contaier mt-3">
                        <center>
                            <a target="_blank" href="../../grades-sample.pdf">
                            <?php 
                            $user_check = $_SESSION['login_user'];
                            $query1 = mysqli_query($connection, "SELECT * FROM tblusers WHERE email = '$user_check'");
						    while($getcollege = mysqli_fetch_array($query1))
						    { 
							    $college_check = $getcollege['college_id_fk'];
							    $getdata = mysqli_query($connection,"SELECT * FROM tblcollege WHERE id='$college_check'");

							    while($fa = mysqli_fetch_array($getdata))
							    {
								    $boom = $fa['seal'];
								    echo "<span id='department'>  "."<img style='width: 2rem; height: 2rem; margin-right: 10px;' src='../SuperAdmin/images/$boom'>".$fa['college']."</span>";
							    }
						    }							
					        ?> 
                            </a>
                            <br>
                            <label class=" mt-0 pt-0 mb-3 text-danger " for="proof">Click picture to view</label>
                            <br>

                            <input type="hidden" name="studemail" value="<?php echo $Getemail?>">

                            <!-- comment -->
                            <div class="mb-1 w-75">
                                <label for="comment" class="form-label">Comment</label>
                                <textarea name="comment" class="form-control form-control-sm" id="comment" rows="2" required></textarea>
                            </div>
                            <br />

                            <!-- buttons -->
                            <div class="container" id="buttons">
                                
                                <a href="" type="submit" name="update-grades" class="btn btn-success border-0 text-white mb-2 p-1 mx-0 w-75 text-white">Approve</a>
                                <input type="submit" name="update-dissaproval-grades" class="btn btn-danger  border-0 mb-2 p-1 mx-0 w-75 text-white" value="Disapprove" />
                                <a  onclick="history.back()" class="btn w-75 bg-secondary border-0 text-white mb-2 p-1 mx-0">Cancel</a>
                            </div>
                        </center>
                    </div>
                </div>
            </div>
        </form>
    </div>
    <!-- CONTENT END -->

  <!-- REQUEST POPUP -->
  <div class="container container-fluid">
			<div class="modal fade" id="manage-request" tabindex="-1" aria-labelledby="manage-requestLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title fw-bold" id="manage-requestLabel">Student Account Request</h5>
							<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
						</div>

						<div class="modal-body">
							<!-- Inputs -->
							<form action="addstudent.php" method="POST">
								<div class="mb-3">
									<label for="input-name" class="form-label">Full Name</label>
									<input type="text" class="form-control" id="input-name" aria-describedby="input-name-help" value="<?php echo $fullname;?>" readonly />
									<!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
								</div>

								<div class="mb-3">
									<label for="input-id" class="form-label">Student ID</label>
									<input type="text" class="form-control" id="input-id" value="<?php echo $username; ?>" readonly />
								</div>

								<div class="mb-3">
									<label for="input-email" class="form-label">Email</label>
									<input type="email" class="form-control" id="input-email" value="<?php echo $email; ?>" readonly />
								</div>

								<div class="mb-3">
									<label for="input-advised" class="form-label">Course and Year</label>
									<input type="text" class="form-control" id="input-advised" value="<?php echo $courseY; ?>" readonly />
								</div>

								<div align="right">
									<button type="button" class="btn btn-danger" data-bs-dismiss="modal">Decline</button>
									<button type="submit" class="btn btn-success">Approve</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- REQUEST END -->

    <!-- Option 2: Separate Popper and Bootstrap JS -->
		<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js" integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU" crossorigin="anonymous"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js" integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj" crossorigin="anonymous"></script>
		<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
        <script>
		$('#table').DataTable({
			initComplete: function () {
				this.api().columns().every( function(){
					var column = this;
					var select = $('<select><option value=""></option></select>')
					.appendTo( $(column.head()).empty() )
					.on( 'change', function () {
						var val = $.fn.DataTable.util.escapeRegex(
							$(this).val()
						);

						column
							.search( val ? '^'+val+'$' : '', true, false)
							.draw();
					});
					column.data().unique().sort().each( function (d,j) {
						select.append( '<option value="'+d+'">'+d+'</option>')
					});
				});
			}
		});

</body>
</html>