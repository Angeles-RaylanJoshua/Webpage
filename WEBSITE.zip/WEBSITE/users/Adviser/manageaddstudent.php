<?php
    include("../../includes/config.php");

    if (isset($_POST['student_check'])) {
        $studid = $_POST['studid'];
        $sql = "SELECT * FROM tblusers WHERE uniId='$studid'";
        $results = mysqli_query($connection, $sql);
        if (mysqli_num_rows($results) > 0) {
          echo 'taken';	
        }else{
          echo 'not_taken';
        }
        exit();
    }
    if (isset($_POST['email_check'])) {
        $email = $_POST['email'];
        $sql = "SELECT * FROM tblusers WHERE email='$email'";
        $results = mysqli_query($connection, $sql);
        if (mysqli_num_rows($results) > 0) {
          echo 'taken';	
        }else{
          echo 'not_taken';
        }
        exit();
    }
	 	if (isset($_POST['save']))
		{
            $Fullname=mysqli_real_escape_string($connection,$_POST['fullname']);
            $studid=mysqli_real_escape_string($connection,$_POST['studid']);
            $Email=mysqli_real_escape_string($connection,$_POST['email']);
            $Password=mysqli_real_escape_string($connection,$_POST['password']);
            $CourseID=mysqli_real_escape_string($connection,$_POST['curid']);
            $Year=mysqli_real_escape_string($connection,$_POST['curlevel']);
            $Colid=mysqli_real_escape_string($connection,$_POST['colid']);
            $studentStat=mysqli_real_escape_string($connection,$_POST['studentStat']);
            $iparr = explode (",",$Fullname,2);
            $firstname = $iparr[1];
            $lastname = $iparr[0];
            $Usertype = 'Student';
            $status = '1';

            $sql = "SELECT * FROM email tblusers WHERE email='$Email'";
  	        $results = mysqli_query($connection, $sql);
  	        if (mysqli_num_rows($results) > 0) {
  	            echo "exists";	
  	            exit();
            }else{

            $query2="INSERT INTO tblusers ( college_id_fk, email, password, usertype, uniId, firstname, lastname, status, per_status, courseid_fk, yearlevel) VALUES ('$Colid','$Email','$Password','$Usertype','$studid','$firstname','$lastname','$status','$studentStat','$CourseID','$Year')";
        
            $results=mysqli_query($connection,$query2);
                echo 'Saved!';     
                header("location:adviser-student-lists.php");
                exit(); 
            }
        }
	mysqli_close($connection);
?>