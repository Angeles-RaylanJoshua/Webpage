<?php
include("../../includes/config.php");

 if(isset($_POST['update-dissaproval-grades']))
    {
        $Subid=mysqli_real_escape_string($connection,$_POST['studemail']);
        $Subcomment=mysqli_real_escape_string($connection,$_POST['comment']);
        $Dissap ="Disapprove";

        $sql_s = "SELECT * FROM tblsub_grades WHERE student_email='$Subid'";
        $sql_e = mysqli_query($connection,$sql_s);

        if(mysqli_num_rows($sql_e) > 0)
        {
            $fetch = mysqli_fetch_array($sql_e);
            $getid = $fetch['student_email'];
        }

        $sqli = "UPDATE tblsub_grades SET status='$Dissap' , comment='$Subcomment' WHERE student_email='$getid'";
        
        if(mysqli_query($connection,$sqli))
        {
            header("location: adviser-submissions.php");
        }
        else
        {
            echo "ERROR:Could not be able to execute $sqli. " .mysqli_error($connection);
        }
    }
?>