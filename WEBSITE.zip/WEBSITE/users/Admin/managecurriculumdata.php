<?php
    session_start();
    include("../../includes/config.php");

	$user_check = $_SESSION['login_user'];
	$query1 = mysqli_query($connection, "SELECT * FROM tblusers WHERE email = '$user_check'");

    if (isset($_POST['add']))
    {
        $CMO=mysqli_real_escape_string($connection,$_POST['CMO']);
        $BR=mysqli_real_escape_string($connection,$_POST['BoardResolution']);
        $SYfrom=mysqli_real_escape_string($connection,$_POST['SYfrom']);
        $SYto=mysqli_real_escape_string($connection,$_POST['SYto']);
        $College=mysqli_real_escape_string($connection,$_POST['college']);
        $CourseID=mysqli_real_escape_string($connection,$_POST['courseid']);
        $effectiveSY = $SYfrom." - ".$SYto;
        

        $getcurr = "SELECT * FROM tblcurriculum WHERE course_id_fk='$CourseID'";
        $getresult = mysqli_query($connection,$getcurr);
        
        //get course id in the curriculum table
        if(mysqli_num_rows($getresult) > 0){
    
            $getcol = mysqli_fetch_array($getresult);
            $getcourseid = $getcol['course_id_fk'];
        }

        //get course code and display in the curriculum table
        $getcc = "SELECT * FROM tblcourse WHERE id='$getcourseid'";
        $getcoursecode = mysqli_query($connection,$getcc);
        
        if(mysqli_num_rows($getcoursecode) > 0){
    
            $getcol = mysqli_fetch_array($getcoursecode);
            $coursecode = $getcol['coursecode'];
        }

        $sql="INSERT INTO `tblcurriculum`(`curr_code`, `cmo`, `board_reso`, `effectiveSY`,`collegeid_fk`, `course_id_fk`) VALUES ('$coursecode ($effectiveSY)','$CMO','$BR','$effectiveSY','$College',$CourseID)";
    
        if(mysqli_query($connection,$sql))
        {
            $_SESSION['curriculum_alert_message'] = "added";
            header("location:admin-curriculum.php");                   
        }
        else
        {
            echo "ERROR:Could not be able to execute $sql. " .mysqli_error($connection);
        }
        
    }
		
	else if (isset($_POST['delete_curr']))
	{
		$id=$_POST['id'];

		$sql="DELETE FROM tblcurriculum WHERE id='$id'";
		
		if(mysqli_query($connection, $sql))
		{
			$_SESSION['curriculum_alert_message'] = "deleted";
			header("location:admin-curriculum.php");
		} else {
			echo "ERROR: Could not able to execute $sql. " .mysqli_error($connection);
		}
	}
	else if (isset($_POST['update_curr'])){
                     
        $id=mysqli_real_escape_string($connection,$_POST['id']);
		$CMO=mysqli_real_escape_string($connection,$_POST['CMO']);
        $BR=mysqli_real_escape_string($connection,$_POST['BoardResolution']);
        $SYfrom=mysqli_real_escape_string($connection,$_POST['SYfrom']);
        $SYto=mysqli_real_escape_string($connection,$_POST['SYto']);
        $College=mysqli_real_escape_string($connection,$_POST['college']);
        $CourseID=mysqli_real_escape_string($connection,$_POST['courseid']);
        $effectiveSY = $SYfrom." - ".$SYto;

			 // Attempt update query execution
			 $sql = "UPDATE tblcurriculum SET curr_code='($effectiveSY)',cmo='$CMO',board_reso='$BR',effectiveSY='$effectiveSY',collegeid_fk='$College',course_id_fk='$CourseID' WHERE id='$id'";
				
            if(mysqli_query($connection, $sql)){
               header("location:admin-curriculum.php"); 
            } else {
                echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
            }
        }
	mysqli_close($connection);
?>