<?php
	session_start();
	include("../../includes/logout.php");
    include("../../includes/config.php");
    include("../../includes/subjectsalertmessage.php");
     
    $user_check = $_SESSION['login_user'];
    $user_col = $_SESSION['college_id_fk'];
	$query1 = mysqli_query($connection, "SELECT * FROM tblusers WHERE email = '$user_check'");
    while($fa = mysqli_fetch_array($query1))
    {
        $detected = $fa['college_id_fk'];
        $cour = $fa['courseid_fk'];
    }

    $query2 = mysqli_query($connection, "SELECT * FROM tblcourse WHERE collegeid_fk = '$detected'");
    while($fa = mysqli_fetch_array($query2))
    {
        $detectedcourseid = $fa['id'];
        $detectedcourse = $fa['course'];
        $detectedyear = $fa['yearlevels'];
    }

    $query3 = mysqli_query($connection, "SELECT * FROM tblsections");
    while($sa = mysqli_fetch_array($query3))
    {
        $detectedsecid = $sa['id'];
        $detectedseccode = $sa['sectioncode'];
        $detectedsecname = $sa['section_name'];
        $detectedsecAvail = $sa['available_slots'];
        $detectedsecNum = $sa['number_of_students'];
        $detectedTotal = $detectedsecAvail - $detectedsecNum;
        $detectedseccol = $sa['college'];
    }

    //$query4 = mysqli_query($connection,"SELECT SUM(yearlevel) AS totalYear FROM tblusers WHERE usertype='Student' and courseid_fk='$detectedcourseid' and yearlevel='$detectedyear'");
    
   // $total=mysqli_fetch_assoc($query4);

    //$totals = $total['totalYear'];

    //$query5 = mysqli_query($connection,"UPDATE tblsections SET number_of_students='$totals'");

   // Use select query 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- BOOTSTRAP -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous" />
    <link rel="stylesheet" href="../../bootstrap/bootstrap.min.css" />
    <!-- fontawesome -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />
    <!-- DATATABLE -->
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/dataTables.bootstrap4.css"/>
    <!-- local css -->
    <link rel="stylesheet" href="../../css/style-admin.css" />
    
    <title>Sections</title>
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-dark" id="navbar">
        <div class="container-fluid">
            <!-- ICS LOGO -->
            <a class="navbar-brand p-0 m-0" href="#" id="nav-logo">
            <?php 
                    $user_check = $_SESSION['login_user'];
                    $query1 = mysqli_query($connection, "SELECT * FROM tblusers WHERE email = '$user_check'");
						while($getcollege = mysqli_fetch_array($query1))
						{ 
							$college_check = $getcollege['college_id_fk'];
							$getdata = mysqli_query($connection,"SELECT * FROM tblcollege WHERE id='$college_check'");

							while($fa = mysqli_fetch_array($getdata))
							{
								$boom = $fa['seal'];
								echo "<span id='department'>  "."<img style='width: 2rem; height: 2rem; margin-right: 10px;' src='../SuperAdmin/images/$boom'>".$fa['college']."</span>";
							}
						}							
					?> 
            </a>

            <!-- MOBILE TOGGLE -->
            <button class="navbar-toggler m-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span><i class="fas fa-bars"></i></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav">
                    <!-- Profile -->
                    <li class="nav-item">
                        <a class="nav-link active py-0" aria-current="page" href="admin-myprofile.php"><i id="icons" class="fas fa-user-tie"></i><span class="nav-label"> My Profile</span></a>
                    </li>
                    <!-- Home -->
                    <li class="nav-item">
                        <a class="nav-link active py-0" aria-current="page" href="admin-homepage.php"><i id="icons" class="fas fa-home"></i><span class="nav-label"> Home</span></a>
                    </li>
                    <!-- notifications -->
                    <li class="nav-item dropstart">
                        <a class="nav-link dropstart active py-0" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false"> <i id="icons" class="fas fa-bell"></i><span class="badge rounded-pill bg-info text-white align-text-top" id="notif-number">4</span><span class="nav-label"> Notifications</span> </a>
                        <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <li>
                                <a data-bs-toggle="modal" data-bs-target="#manage-request" class="dropdown-item" href="#"><span class="text fw-bold">Adviser One</span> requested an account</a>
                            </li>
                            <li>
                                <a data-bs-toggle="modal" data-bs-target="#manage-request" class="dropdown-item" href="#"><span class="text fw-bold">Adviser Two</span> requested an account</a>
                            </li>
                            <li>
                                <a data-bs-toggle="modal" data-bs-target="#manage-request" class="dropdown-item" href="#"><span class="text fw-bold">Adviser Three</span> requested an account</a>
                            </li>
                           
                        </ul>
                    </li>
                    <!-- logout -->
                    <li class="nav-item">
                        <a id="icons" class="nav-link active py-0"  data-bs-toggle="modal" data-bs-target="#logoutmodal" aria-disabled="true"><i class="fas fa-sign-out-alt"></i><span class="nav-label"> Logout</span></a>
					</li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- END OF NAVBAR -->


    <div class="container">
        <p class="text  mt-3 text-danger fw-bold text-center fs-2">Sections</p>
	</div>

    <!-- TABLE -->
    <div class="container p-2 container-fluid mb-3" >
        <div class="container overflow-auto" >
            <table class="table table-hover table-responsive table-striped table-bordered " id="table">
                <thead class="text-white">
                    <tr>
                        <th hidden>ID</th>
                        <th>Section Code</th>
                        <th>Section </th>
                        <th>Course</th>
                        <th>Number of Students</th>
                        <th>Available Slots</th>
                        <th class="text-center">Action</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $getcol = $_SESSION['college_id_fk'];
                
                $sqls = "SELECT * FROM tblsections WHERE college='$getcol' and course_id_fk='$detectedcourseid' and yearlevel='$detectedyear'";

                $sql = mysqli_query($connection,$sqls) or die( mysqli_error($connection));
                    //<tr onclick="window.location='#';" data-bs-toggle="modal" > 
                while($fa=mysqli_fetch_array($sql))
                {         
                    $alltotal = $fa['available_slots'] - $fa['number_of_students'];
                    echo "<td hidden><center>".$id=$fa['id']."</center></td>";
                    echo "<td><center>".$fa['sectioncode']."</center></td>";
                    echo "<td><center>".$fa['section_name']."</center></td>";
                    echo "<td>".$detectedcourse."</td>";
                    echo "<td><center>".$detectedsecNum."</center></td>";
                    echo "<td><center>".$alltotal."</center></td>";
                    echo "<center><td class='col-3 text-center'> <button type='button' class='fas fa-edit btn rounded-pill btn-success editbtn'>  Edit</button> ";

                    echo "<button type='button' class='fas fa-trash btn rounded-pill btn-danger deletebtn'>  Delete</button></td></center>";
                    echo "</tr>";
                }
                ?>
                    </tr>
                </tbody>
                <tfoot >	
                    <!-- table footer -->
                </tfoot>
            </table>
        </div>


        <!-- ADD SECTION Toggle-->
        <center>
            <button type="button" class="btn rounded-pill btn-danger mb-3" data-bs-toggle="modal" data-bs-target="#addSection" id="add-section">
                Add Section
            </button>
        </center>
        
    </div>
    <!-- TABLE END -->

  
    
    <!-- ADD NEW Section POPUP -->
    <div class="container container-fluid">
        <div class="modal fade" id="addSection" tabindex="-1" aria-labelledby="addSectionLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title fw-bold" id="addSectionLabel">Add New Section</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>

                    <div class="modal-body">
                        <!-- Inputs -->
                        <form action="managesectionsdata.php" method="POST">
                            <div class="mb-3">
                                <label for="input-sectionID" class="form-label">Section Code</label>
                                <input type="text" name="sectioncode" class="form-control" id="sectioncode" aria-describedby="input-sectionID-help" required>
                                <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
                            </div>

                            <div class="mb-3">
                                <label for="input-sectionID" class="form-label">Section Name</label>
                                <input type="text" name="sectionname" class="form-control" id="sectionname" aria-describedby="input-sectionID-help" required>
                                <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
                            </div>

                            <div class="container p-0 mb-3" id="select-course">
                                <label for="select-course" class="form-label" >Course</label>
                                <select class="custom-select p-2 " name="course" id="select-course" required>
                                    <option value="none">Select Course...</option>
                                    <?php
                                        $usercol = $_SESSION['college_id_fk'];
                                        $usercour = $_SESSION['courseid_fk'];
                                        
                                        $getcurs = mysqli_query($connection,"SELECT * FROM tblcourse WHERE id='$detectedcourseid' and collegeid_fk='$usercol'");

                                        while($sa=mysqli_fetch_array($getcurs))
                                        {
                                            $id = $sa['id'];
                                            $course = $sa['course'];
                                            echo "<option value='".$id."'>" .$course."</option>";  
                                            // displaying data in option menu
                                        }                 	
                                    ?>   
                                </select>			
                            </div>

                            <div class="mb-3">
                                <label for="input-sectionID" class="form-label">Slots Per Section</label>
                                <input type="text" name="sectionslot" class="form-control" id="sectionslot" aria-describedby="input-sectionID-help" required>
                                <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
                            </div>

                            <div class="container p-0 mb-3" id="select-course">
                            <label for="select-course" class="form-label" >Year</label>
                            <select class="custom-select p-2 " name="year" id="select-course" required>
                                <option selected>Select Year...</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                            </select>			
                            </div>	

                            <div class="mb-3">
                                <input type="hidden" name="college" value="<?php echo $detected?>" class="form-control" id="input-sectionID" aria-describedby="input-sectionID-help" required>
                                <!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
                            </div>

                            <div align="right">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                <button type="submit" name="add-section" class="btn btn-primary">Confirm</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ADD SECTION END -->

   
    <!-- SECTION MANAGE (edit or delete) -->
    <div class="modal fade" id="edit-section-modal" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="manage-curriculum" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content ">
            <div class="modal-header">
                <h5 class="modal-title fw-bold" id="manage-curriculum">Manage Section</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <!-- Inputs -->

                <form action="managesectionsdata.php" method="POST">
                    <div class="mb-3">
                        <input type="hidden" name="id" value="<?php echo $detectedsecid?>" id="currid">

                        <label for="cmo" class="form-label">Section Code</label>
                        <input type="text" class="form-control" id="sectioncode" name="sectioncode" value="<?php echo $detectedseccode?>"required>
                        
                    </div>

                    <div class="mb-3">
                        <label for="#br" class="form-label">Section Name</label>
                        <input type="text" class="form-control" id="sectionname" name="sectionname" value="<?php echo $detectedsecname?>" required>
                    </div>

                    <?php
                            
                        $college_check = $_SESSION['college_id_fk'];
                        $query3 = mysqli_query($connection, "SELECT * From tblcourse WHERE collegeid_fk='$college_check'");  
                        // Use select query 

                        while($da = mysqli_fetch_array($query3))
                        {
                            $getcourid = $da['course'];
                            $getcourname = $da['course'];
                            // displaying data in option menu
                        }	
                    ?>  

                    <!-- Course -->		
                    <div class="container p-0 mb-3" id="select-course">
                        <label for="#select-course" class="form-label" >Course</label>
                        <select class="custom-select p-2 " id="select-course" name="course" id="courseid" required>
                        <option selected><?php echo $getcourname?></option>

                        <!-- FETCH COURSES FROM DATABASE -->
                            <?php
                            
                                $college_check = $_SESSION['college_id_fk'];
                                $query3 = mysqli_query($connection, "SELECT * From tblcourse WHERE collegeid_fk='$college_check'");  
                                // Use select query 

                                while($fa = mysqli_fetch_array($query3))
                                {
                                    $GetcourId = $fa['id'];
                                    echo "<option value='". $fa['course'] ."'>" . $fa['course'] ."</option>";  
                                    // displaying data in option menu
                                }	
                            ?>  
                        </select>			
                    </div>	
                    <input type="hidden" class="form-control" id="courseid" name="courseid" value="<?php echo $GetcourId?>" required>

                    <div class="mb-3">
                        <label for="#br" class="form-label">Slots Per Section</label>
                        <input type="text" class="form-control" id="sectionavail" name="sectionavail" value="<?php echo $detectedsecAvail?>" required>
                    </div>	

                    <div align="right">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" name="update_section" class="btn btn-primary">Confirm</button>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
    <!-- MANAGE CURRICULUM (edit or delete) END -->

    <!-- REQUEST POPUP -->
		<div class="container container-fluid">
			<div class="modal fade" id="manage-request" tabindex="-1" aria-labelledby="manage-requestLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title fw-bold" id="manage-requestLabel">Adviser Account Request</h5>
							<button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
						</div>
	
						<div class="modal-body">
							<!-- Inputs -->
							<form>
								<div class="mb-3">
									<label for="input-name" class="form-label">Name</label>
									<input type="text" class="form-control" id="input-name" aria-describedby="input-name-help" 
										value="Juan Dela Cruz"
									readonly>
									<!-- <div id="emailHelp" class="form-text">We'll never share your email with anyone else.</div> -->
								</div>
	
								<div class="mb-3">
									<label for="input-id" class="form-label">Employee ID</label>
									<input type="text" class="form-control" id="input-id" 
										value="EMP3000"
									readonly>
								</div>

								<div class="mb-3">
									<label for="input-email" class="form-label">Email</label>
									<input type="email" class="form-control" id="input-email" 
										value="emp3000@wmsu.edu.ph"
									readonly>
								</div>

								<div class="mb-3">
									<label for="input-advised" class="form-label">Advised To</label>
									<input type="text" class="form-control" id="input-advised" 
										value="BSCS1A"
									readonly>
								</div>
	
								<div align="right">
									<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Delete</button>
									<button type="submit" class="btn btn-success">Approve</button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- REQUEST END -->
        <!-- DELETE MODAL-->
	<div class="container container-fluid">
        <div class="modal fade" id="deletemodal" tabindex="-1" aria-labelledby="deletemodalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="managesectionsdata.php" method="POST">
                        <center>
                            <input type="hidden" name="id" id="deleteid">

                            <div class="modal-body">
                                All data related to this Curriculum will also be permanently deleted!<br>
                                Are you sure you want to delete this Section?
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                                <button type="submit" name="delete_section" class="btn btn-danger">Yes</button>
                            </div>                     
                        </center>
                    </form>
                </div>
            </div>
        </div>
	<!--END OF DELETE MODAL-->

    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"
      integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js"
      integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj"
      crossorigin="anonymous"
    ></script>
    <script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
    <script type="text/javascript" src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.23/js/dataTables.bootstrap4.js"></script>

    <script>
        $(document).ready(function()
        {
            $('.deletebtn').on('click',function()
            {
                $('#deletemodal').modal('show');

                    $tr= $(this).closest('tr');

                    var data = $tr.children('td').map(function(){
                        return $(this).text(); 
                    }).get();

                    console.log(data);

                    $('#deleteid').val(data[0]);
            });
        });
    </script>

    <script>
            $(document).ready(function()
            {
                $('.editbtn').on('click',function()
                {

                    $('#edit-section-modal').modal('show');

                    


                });
            });

    </script>

    <script>
		$('#table').DataTable();
	</script>

</body>
</html>