<?php
    session_start();
    include("../../includes/config.php");
    $user_check = $_SESSION['login_user'];
	$query1 = mysqli_query($connection, "SELECT * FROM tblusers WHERE email = '$user_check'");

    if (isset($_POST['add']))
    {
        $Subjectid=mysqli_real_escape_string($connection,$_POST['subjectid']);
        $SubjectCode=mysqli_real_escape_string($connection,$_POST['subjectcode']);
        $SubjectTitle=mysqli_real_escape_string($connection,$_POST['title']);
        $SubjectType=mysqli_real_escape_string($connection,$_POST['subjecttype']);
        $Lec=mysqli_real_escape_string($connection,$_POST['Lec']);
        $Lab=mysqli_real_escape_string($connection,$_POST['Lab']);
        $Units=mysqli_real_escape_string($connection,$_POST['units']);
        $Time=mysqli_real_escape_string($connection,$_POST['time']);
        $Day=mysqli_real_escape_string($connection,$_POST['day']);
        $College=mysqli_real_escape_string($connection,$_POST['collegeid']);
        $Course=mysqli_real_escape_string($connection,$_POST['course']);
        $Prereq=mysqli_real_escape_string($connection,$_POST['prereq']);
        $Semester=mysqli_real_escape_string($connection,$_POST['semester']);
        $Yearlevel=mysqli_real_escape_string($connection,$_POST['yearlevel']);
        $subjectsID=mysqli_real_escape_string($connection,$_POST['currid']);
    
        $_SESSION['currid'] =   $subjectsID;

        $sql="INSERT INTO `tblsubject`(`subjectid`,`curr_id_fk`, `subject_code`, `sub_type`, `title`, `lec`, `lab`, `units`,`time`,`day`,`college`,`course`, `prereq`, `semester`, `year`) VALUES ('$Subjectid','$subjectsID', '$SubjectCode','$SubjectTitle','$SubjectType',$Lec,$Lab,$Units,'$Time','$Day','$College','$Course','$Prereq','$Semester','$Yearlevel')";
    
        if(mysqli_query($connection,$sql))
        {   
            $_SESSION['subjects_alert_message'] = "added";
            header("location: admin-subjects.php");            
        }
        else
        {
            echo "ERROR:Could not be able to execute $sql. " .mysqli_error($connection);
        }
        
    }
    if (isset($_POST['delete_sub']))
	{
		$id=$_POST['subjectid'];

		$sql="DELETE FROM tblsubject WHERE subjectid='$id'";
		
		if(mysqli_query($connection, $sql))
		{
			$_SESSION['subjects_alert_message'] = "deleted";
			header("location:admin-subjects.php");
		} else {
			echo "ERROR: Could not able to execute $sql. " .mysqli_error($connection);
		}
	}
    if (isset($_POST['update_sub'])){
        $id=mysqli_real_escape_string($connection,$_POST['id']);  
        $Subid=mysqli_real_escape_string($connection,$_POST['subjectid']);
		$Subcurri=mysqli_real_escape_string($connection,$_POST['curriid']);
        $Subcode=mysqli_real_escape_string($connection,$_POST['subjectcode']);
        $Subtitle=mysqli_real_escape_string($connection,$_POST['title']);
        $Subtype=mysqli_real_escape_string($connection,$_POST['subjecttype']);
        $Sublec=mysqli_real_escape_string($connection,$_POST['lec']);
        $Sublab=mysqli_real_escape_string($connection,$_POST['lab']);
        $Subtime=mysqli_real_escape_string($connection,$_POST['time']);
        $Subday=mysqli_real_escape_string($connection,$_POST['day']);
        $Subunits=mysqli_real_escape_string($connection,$_POST['units']);
        $Subsemester=mysqli_real_escape_string($connection,$_POST['semester']);
        $Subcourse=mysqli_real_escape_string($connection,$_POST['courid']);
        $Subprereq=mysqli_real_escape_string($connection,$_POST['subid']);
        $Sublevel=mysqli_real_escape_string($connection,$_POST['yearlevel']);
        $Subcollege=mysqli_real_escape_string($connection,$_POST['collegeid']);

			 // Attempt update query execution
			 $sql = "UPDATE tblsubject SET subjectid='$Subid', curr_id_fk='$Subcurri',subject_code='$Subcode',sub_type='$Subtype',title='$Subtitle',lec='$Sublec',lab='$Sublab',units='$Subunits',time='$Subtime',day='$Subday',college='$Subcollege',course='$Subcourse',prereq='$Subprereq',semester='$Subsemester',year='$Sublevel' WHERE id='$id'";
				
            if(mysqli_query($connection, $sql)){
               $_SESSION['subjects_alert_message'] = "Updated";
               header("location: admin-subjects.php"); 
            } else {
                echo "ERROR: Could not able to execute $sql. " .mysqli_error($connection);
            }
        }
	mysqli_close($connection); 
?>