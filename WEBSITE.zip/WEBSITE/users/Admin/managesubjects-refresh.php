<?php
    session_start();
    include("../../includes/config.php");

    if (isset($_POST['add']))
    {
        $Semester=mysqli_real_escape_string($connection,$_POST['semester']);
        $Yearlevel=mysqli_real_escape_string($connection,$_POST['yearlevel']);
        $subjectsID=mysqli_real_escape_string($connection,$_POST['currid']);
    
        if($Semester == "1st Semester")
        {
            $dissub = mysqli_query($connection, "SELECT * FROM tblsubject WHERE semester='$Semester'");
                        
            while($dis = mysqli_fetch_array($dissub))
            {         
                echo "<tr>";
                echo "<td>".$dis['subjectid']."</td>";
                echo "<td>".$dis['subject_code']."</td>";
                echo "<td>".$dis['title']."</td>";
                echo "<td>".$dis['lec']."</td>";
                echo "<td>".$dis['lab']."</td>";
                echo "<td>".$dis['units']."</td>";
                echo "<td>".$dis['prereq']."</td>";

                echo "<center><td class='col-3 text-center'> <button type='button' class='fas fa-edit btn rounded-pill btn-success editbtn'>  Edit</button> ";

                echo "<button type='button' class='fas fa-trash btn rounded-pill btn-danger deletebtn'>  Delete</button></td></center>";

                echo "</tr>";
            }
        }
        else if($Semester == "2nd Semester")
        {
            $dissub = mysqli_query($connection, "SELECT * FROM tblsubject WHERE semester='$Semester'");
                        
            while($dis = mysqli_fetch_array($dissub))
            {         
                echo "<tr>";
                echo "<td>".$dis['subjectid']."</td>";
                echo "<td>".$dis['subject_code']."</td>";
                echo "<td>".$dis['title']."</td>";
                echo "<td>".$dis['lec']."</td>";
                echo "<td>".$dis['lab']."</td>";
                echo "<td>".$dis['units']."</td>";
                echo "<td>".$dis['prereq']."</td>";

                echo "<center><td class='col-3 text-center'> <button type='button' class='fas fa-edit btn rounded-pill btn-success editbtn'>  Edit</button> ";

                echo "<button type='button' class='fas fa-trash btn rounded-pill btn-danger deletebtn'>  Delete</button></td></center>";

                echo "</tr>";
            }
        }
        else
        {
            echo "ERROR:Could not be able to execute $sql. " .mysqli_error($connection);
        }
        
    }
	mysqli_close($connection); 
?>