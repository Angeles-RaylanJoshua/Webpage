<?php
    session_start();
    include("../../includes/config.php");

	$user_check = $_SESSION['login_user'];
    $user_year = $_SESSION['yearlevel'];
	$query1 = mysqli_query($connection, "SELECT * FROM tblusers WHERE email = '$user_check'");

    if (isset($_POST['add-section']))
    {
        $sectioncode=mysqli_real_escape_string($connection,$_POST['sectioncode']);
        $sectionname=mysqli_real_escape_string($connection,$_POST['sectionname']);
        $course=mysqli_real_escape_string($connection,$_POST['course']);
        $sectionslot=mysqli_real_escape_string($connection,$_POST['sectionslot']);
        $college=mysqli_real_escape_string($connection,$_POST['college']);
        $year=mysqli_real_escape_string($connection,$_POST['year']);

        $query4 = mysqli_query($connection,"SELECT SUM(yearlevel) AS totalYear FROM tblusers WHERE yearlevel='$year' and usertype='Student' and courseid_fk='$course'");
    
        $total=mysqli_fetch_assoc($query4);

        if($total !== $year ){
            $totals;
            $Year = $year;
        }
        else{
            $Year = $year;
            $totals = $total['totalYear'];
            $getTotal = $sectionslot - $totals;
        }

        $sql = " INSERT INTO tblsections (sectioncode,section_name,number_of_students,available_slots,total_slots,yearlevel,course_id_fk,college) VALUES ('$sectioncode','$sectionname',$totals,'$sectionslot','$getTotal','$Year','$course','$college')";

        if(mysqli_query($connection,$sql))
        {
            $_SESSION['curriculum_alert_message'] = "added";
            header("location:admin-sections.php");                   
        }
        else
        {
            echo "ERROR:Could not be able to execute $sql. " .mysqli_error($connection);
        }
    }

    if (isset($_POST['update_section']))
	{
        $id=mysqli_real_escape_string($connection,$_POST['id']);  
        $SecCode=mysqli_real_escape_string($connection,$_POST['sectioncode']);
		$SecName=mysqli_real_escape_string($connection,$_POST['sectionname']);
        $SecAvail=mysqli_real_escape_string($connection,$_POST['sectionavail']);
        $SecCour=mysqli_real_escape_string($connection,$_POST['courseid']);


            $up = "SELECT * FROM tblsections WHERE id='$id'";
            $query = mysqli_query($connection,$up);

            if(mysqli_num_rows($query) > 0){
    
                $getid = mysqli_fetch_array($query);
                $getnum = $getid['number_of_students'];
                $Total = $SecAvail - $getnum;
            }

		    $sql="UPDATE tblsections SET sectioncode='$SecCode', section_name='$SecName', available_slots='$SecAvail',total_slots='$Total',course_id_fk='$SecCour' WHERE id='$id' ";
		
		    if(mysqli_query($connection, $sql))
		    {
			    $_SESSION['curriculum_alert_message'] = "deleted";
			    header("location:admin-sections.php");
		    } else {
			    echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
		    }
	}

	if (isset($_POST['delete_section']))
	{
		$id=$_POST['id'];

		$sql="DELETE FROM tblsections WHERE id='$id'";
		
		if(mysqli_query($connection, $sql))
		{
			$_SESSION['curriculum_alert_message'] = "deleted";
			header("location:admin-sections.php");
		} else {
			echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
		}
	}
	mysqli_close($connection);
?>