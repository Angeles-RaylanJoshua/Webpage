<?php
    session_start();
    include("../../includes/config.php");


	 	if (isset($_POST['add_subject']))
		{
            $Firstname=mysqli_real_escape_string($connection,$_POST['firstname']);
            $Lastname=mysqli_real_escape_string($connection,$_POST['lastname']);
            $Email=mysqli_real_escape_string($connection,$_POST['email']);
            $Password=mysqli_real_escape_string($connection,$_POST['password']);
            $Usertype=mysqli_real_escape_string($connection,$_POST['usertype']);
            $CourseID=mysqli_real_escape_string($connection,$_POST['courseid']);
            $Year=mysqli_real_escape_string($connection,$_POST['yearlevel']);
            $Collegeid=mysqli_real_escape_string($connection,$_POST['collegeid']);
            $status = 1;
            $assigned = 1;
            $per = 0;
            
            //insert data
            $sql="INSERT INTO `tblusers`(`college_id_fk`, `email`, `password`, `usertype`, `firstname`, `lastname`,`status`, `per_status`, `courseid_fk`,`yearlevel`,`already_assigned`) VALUES ($Collegeid,'$Email','$Password','$Usertype','$Firstname','$Lastname','$status','$per','$CourseID','$Year',$assigned)";
        
            if(mysqli_query($connection,$sql))
            {
                $_SESSION['adviser_alert_message'] = "added";
                header("location: admin-advisers.php"); 
            }
            else
            {
                echo "ERROR:Could not be able to execute $sql. " .mysqli_error($connection);
            }
        }
        else if (isset($_POST['update'])){
                     
			$AdminID=mysqli_real_escape_string($connection,$_POST['id']);
            $Username=mysqli_real_escape_string($connection,$_POST['username']);
            $Password=mysqli_real_escape_string($connection,$_POST['password']);
            $CollegeID=mysqli_real_escape_string($connection,$_POST['collegeid']);

			 // Attempt update query execution
			 $sql = "UPDATE tblusers SET username='$Username',password='$Password',collegeid='$CollegeID' WHERE id='$AdminID'";
				
            if(mysqli_query($connection, $sql)){
                $_SESSION['adviser_alert_message'] = "updated";
                header("location:superadmin-admins.php"); 
            } else {
                echo "ERROR: Could not able to execute $sql. " . mysqli_error($connection);
            }
        }
	mysqli_close($connection);
?>