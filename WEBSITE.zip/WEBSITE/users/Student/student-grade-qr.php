<?php
	session_start();
	include("../../includes/logout.php");
    include("../../includes/config.php");
     
    $user_check = $_SESSION['login_user'];
    $user_col = $_SESSION['college_id_fk'];
	$query1 = mysqli_query($connection, "SELECT * FROM tblusers WHERE email = '$user_check'");
    while($fa = mysqli_fetch_array($query1))
    {
		$detectedfirst = $fa['firstname'];
		$detectedlast = $fa['lastname'];
		$detectedfull = ucfirst($detectedfirst).' '.ucfirst($detectedlast);
        $detected = $fa['college_id_fk'];
        $cour = $fa['courseid_fk'];
    }

    $query2 = mysqli_query($connection, "SELECT * FROM tblcourse WHERE collegeid_fk = '$detected'");
    while($fa = mysqli_fetch_array($query2))
    {
        $detectedcourseid = $fa['id'];
        $detectedcourse = $fa['course'];
        $detectedyear = $fa['yearlevels'];
    }

    $query3 = mysqli_query($connection, "SELECT * FROM tblsections");
    while($sa = mysqli_fetch_array($query3))
    {
        $detectedsecid = $sa['id'];
        $detectedseccode = $sa['sectioncode'];
        $detectedsecname = $sa['section_name'];
        $detectedsecAvail = $sa['available_slots'];
        $detectedsecNum = $sa['number_of_students'];
        $detectedTotal = $detectedsecAvail - $detectedsecNum;
        $detectedseccol = $sa['college'];
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- BOOTSTRAP -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/dataTables.bootstrap4.css" />
    

    <!-- fontawesome -->
    <link
        rel="stylesheet"
        href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p"
        crossorigin="anonymous"
    />
    <link rel="stylesheet" href="../../bootstrap/fontawesome.min.css" />
    <!-- local css -->
    <link rel="stylesheet" href="../../css/style-student.css" />

    <title>Submit Grade</title>
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-dark" id="navbar">
        <div class="container-fluid">
            <!-- ICS LOGO -->
            <a class="navbar-brand p-0 m-0" href="#" id="nav-logo">
            <?php 
                    $user_check = $_SESSION['login_user'];
                    $query1 = mysqli_query($connection, "SELECT * FROM tblusers WHERE email = '$user_check'");
						while($getcollege = mysqli_fetch_array($query1))
						{ 
							$college_check = $getcollege['college_id_fk'];
							$getdata = mysqli_query($connection,"SELECT * FROM tblcollege WHERE id='$college_check'");

							while($fa = mysqli_fetch_array($getdata))
							{
								$boom = $fa['seal'];
								echo "<span id='department'>  "."<img style='width: 2rem; height: 2rem; margin-right: 10px;' src='../SuperAdmin/images/$boom'>".$fa['college']."</span>";
							}
						}							
					?> 
            </a>

            <!-- MOBILE TOGGLE -->
            <button
                class="navbar-toggler m-0"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent"
                aria-expanded="false"
                aria-label="Toggle navigation"
            >
                <span><i class="fas fa-bars"></i></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav">
                    <!-- logout -->
                    <li class="nav-item" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Logout">
                        <a id="icons" class="nav-link active py-0" href="../../signin/universal-signin.php" aria-disabled="true"><i class="fas fa-sign-out-alt"></i><span class="nav-label"> Logout</span></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- END OF NAVBAR -->

    <!-- CONTENT -->
    <div class="container container-fluid overflow-auto" id="desktop-view">
        <h2 class="text fw-bold text-center mt-4">Submit your grades</h2>
        <h4 class="text-center fw-light">via QR Code</h4>

        <!-- Choices -->
        <div class="container container-fluid p-3 mt-5">
            <div class="row">
                <!-- QR Code -->
                <div class="col-sm-5 ">
                    
                    <div class="choice container container-fluid p-3 rounded " style="height: 100%;" >
                        <p class="badge fs-5 bg-danger rounded-circle">1</p>
                        <center>
                            <img id="grade-icon" src="../../images/qr-sample.png" alt="grades" class="mb-4 w-50 border mt-3 border-4 p-2 rounded">
                        </center>
    
                        <div class="input-group input-group-sm mb-1">
                            <input type="file" class="form-control" accept="image/x-png,image/gif,image/jpeg" id="file" name="file"  aria-label="Upload Grade">
                        </div>
                    </div>
                </div>

                <div class="col-sm-1 mt-5">
                </div>
    
                <!-- MANUAL INPUT -->
                <div class="col-sm-6">
                    <div class="choice container container-fluid p-3 rounded "  style="height: 100%;">

                        <p class="badge fs-5 bg-danger rounded-circle">2</p>
                        <a href="student-grade-input.php" class="btn w-100 mt-3 btn-dark mb-5"><span class="float-start"><i class="fas fa-pen"></i></span> Switch to manual input</a>

                       
                        <button type="button" class="btn  btn-secondary w-100 mb-2" data-bs-toggle="modal" data-bs-target="#help">
                            <span class="float-start"><i class="fas fa-question"></i></span> Help
                        </button>

                        <a  onclick="history.back()" class="btn bg-secondary text-white w-100 mb-2">
                            <span class="float-start"><i class="fas fa-arrow-left"></i></span>Back
                        </a>
                        
                        <button type="button" class="btn btn-danger  w-100 mb-2" data-bs-toggle="modal" data-bs-target="#view">
                            <span class="float-start"><i class="fas fa-check"></i></span> Submit
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Container of Choices END-->

       

        <!-- HELP POPUP -->
        <div class="modal fade" id="help" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">How to use QR Code</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <center>
                            <img src="../../images/instruction.png" class="w-50" alt="instruction">
                        </center>
                        
                        <p>Take a screenshot of the QR Code from the pdf file of your grade and crop it.<br> <a href="http://wmsu.edu.ph/">Download your grades from the WMSU Portal</a><br></p>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- HELP POPUP END -->

        <!-- VIEW POPUP -->
        <div class="modal fade" id="view" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-scrollable">
                <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">QR Code Information</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <p>Information below: <br><br><span id="content"></span></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <a href="student-ii.php" class="btn btn-danger">
                             Confirm
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <!-- VIEW POPUP END -->

      
    </div>
    <!-- CONTENT END -->


    <!-- To Read QR Code -->
    <script type="text/javascript" src="../../bootstrap/qrReader.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
</body>
</html>