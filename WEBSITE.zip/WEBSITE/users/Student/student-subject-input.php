<?php
	session_start();
	include("../../includes/logout.php");
    include("../../includes/config.php");
    include("../../includes/studentalertmessage.php");
     
    $user_check = $_SESSION['login_user'];
    $user_col = $_SESSION['college_id_fk'];
    $user_cour = $_SESSION['courseid_fk'];
    $user_year = $_SESSION['yearlevel'];
	$query1 = mysqli_query($connection, "SELECT * FROM tblusers WHERE email = '$user_check'");
    while($fa = mysqli_fetch_array($query1))
    {
		$detectedfirst = $fa['firstname'];
		$detectedlast = $fa['lastname'];
		$detectedfull = ucfirst($detectedfirst).' '.ucfirst($detectedlast);
        $detected = $fa['college_id_fk'];
        $cour = $fa['courseid_fk'];
    }

    $query2 = mysqli_query($connection, "SELECT * FROM tblcourse WHERE collegeid_fk = '$detected'");
    while($fa = mysqli_fetch_array($query2))
    {
        $detectedcourseid = $fa['id'];
        $detectedcourse = $fa['course'];
        $detectedyear = $fa['yearlevels'];
    }

    $query3 = mysqli_query($connection, "SELECT * FROM tblsections");
    while($sa = mysqli_fetch_array($query3))
    {
        $detectedsecid = $sa['id'];
        $detectedseccode = $sa['sectioncode'];
        $detectedsecname = $sa['section_name'];
        $detectedsecAvail = $sa['available_slots'];
        $detectedsecNum = $sa['number_of_students'];
        $detectedTotal = $detectedsecAvail - $detectedsecNum;
        $detectedseccol = $sa['college'];
    }

    $sql1=mysqli_query($connection,"SELECT * FROM tblusers WHERE usertype='Adviser' and college_id_fk='$user_col' and courseid_fk='$user_cour' and yearlevel='$user_year'");

    while($da = mysqli_fetch_array($sql1))
    {
        $Getid = $da['id'];
        $Getemail = $da['email'];
        $Getcour = $da['courseid_fk'];
        $Getcolid=$da['college_id_fk'];
    }

    $sql_e=mysqli_query($connection,"SELECT SUM(units) AS totalunits FROM tblsubject WHERE college='$user_col' and course='$user_cour' and year='$user_year'");
    
    $total=mysqli_fetch_assoc($sql_e);

    $totals = $total['totalunits'];
    
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <!--Let browser know website is optimized for mobile-->
		<meta name="viewport" content="width=device-width, initial-scale=1.0" />
		<!-- BOOTSTRAP -->
		<link
			href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css"
			rel="stylesheet"
			integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1"
			crossorigin="anonymous"
		/>
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/dataTables.bootstrap4.css" />
		<!-- OFFLINE BOOTSTRAP -->
		<link rel="stylesheet" href="../../bootstrap/bootstrap.min.css" />

		<!-- fontawesome -->
		<link
			rel="stylesheet"
			href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
			integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p"
			crossorigin="anonymous"
		/>
		<link rel="stylesheet" href="../../bootstrap/fontawesome.min.css" />
		<!-- local css -->
		<link rel="stylesheet" href="../../css/style-student.css" />

		<title>Submit Grade</title>
  </head>

  <body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-dark" id="navbar">
        <div class="container-fluid">
            <!-- ICS LOGO -->
            <a class="navbar-brand p-0 m-0" href="#" id="nav-logo">
            <?php 
                    $user_check = $_SESSION['login_user'];
                    $query1 = mysqli_query($connection, "SELECT * FROM tblusers WHERE email = '$user_check'");
						while($getcollege = mysqli_fetch_array($query1))
						{ 
							$college_check = $getcollege['college_id_fk'];
							$getdata = mysqli_query($connection,"SELECT * FROM tblcollege WHERE id='$college_check'");

							while($fa = mysqli_fetch_array($getdata))
							{
								$boom = $fa['seal'];
								echo "<span id='department'>  "."<img style='width: 2rem; height: 2rem; margin-right: 10px;' src='../SuperAdmin/images/$boom'>".$fa['college']."</span>";
							}
						}							
					?> 
            </a>

            <!-- MOBILE TOGGLE -->
            <button
                class="navbar-toggler m-0"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent"
                aria-expanded="false"
                aria-label="Toggle navigation"
            >
                <span><i class="fas fa-bars"></i></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav">
                    <!-- logout -->
                    <li class="nav-item" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Logout">
                        <a id="icons" class="nav-link active py-0" href="../../signin/universal-signin.php" aria-disabled="true"><i class="fas fa-sign-out-alt"></i><span class="nav-label"> Logout</span></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- END OF NAVBAR -->
      
	<center>
        <div class="container bg-light p-2 pt-4 fs-5 mt-3" style="border-radius: 10px; border: transparent;">
            <p>Choose and select your desired subjects to be taken this semester. <span class="fw-bold">Units must be 1-26</span> </p>
        </div>
    </center>

	<div class="container container-fluid">
		<!-- TABLE -->
		<div class="container mb-2 mt-3 mb-5 overflow-auto">
			<table class="table table-responsive table-striped table-bordered pt-2 pb-3" style="width: 100%;" id="mydatatable">
				<thead class=" text-white">
					<tr>                       
                        <th >Code</th>
						<th>Title</th>
						<th scope="col">Units</th>
						<th scope="col">Days</th>
                        <th scope="col">Time</th>
                        <th scope="col">All units</th>
                        <th><center>Action</center></th>
					</tr>
				</thead>
				<tbody>
                <?php
                $sql_s=mysqli_query($connection,"SELECT * FROM tblsubject WHERE college='$user_col' and course='$user_cour' and year='$user_year' ");
                    
                while($sa = mysqli_fetch_array($sql_s))
                {       
                    $Getid = $sa['id'];
                    $Getcode =$sa['subject_code'];
                    $Getname =$sa['title'];
                    $Gettime =$sa['time'];
                    $Getday =$sa['day'];
                    $Getunits =$sa['units'];

					echo "<tr>";
					echo "<th><center>".$Getcode."</center></th>";
					echo "<td><center>".$Getname."</center></td>";
					echo "<td><center>".$Getunits."</center></td>";
					echo "<td><center>".$Getday."</center></td>";
					echo "<td><center>".$Gettime."</center></td>";
                    echo "<td><center>".$totals."</center></td>";
					echo "<td><center><input type='checkbox' name='name1' id='checking' class='checkBox'/>&nbsp;</center></td>";
                    echo "</tr>";
                }
                ?>					
				</tbody>
				
			</table>
		</div>
		<!-- TABLE END -->


        <!-- BUTTONS -->
        <center>
            <button type="button" class="btn btn-dark mb-3 mx-2" data-bs-toggle="modal" data-bs-target="#cancelbtn" >
                Cancel
            </button>
            <button type="button" name="checkAll" class="btn btn-secondary mb-3 mx-2 checkAll " onclick="checking()" id="checkboxAll">
                Check All
            </button>
            <button type="button" name="undo" class="btn btn-secondary mb-3 mx-2 undo" onclick="unchecking()" style="display: none" id="undo"
            >
                Uncheck All
            </button>

            <!-- delete this line if conditioning is working -->
            <button class="btn btn-secondary mb-3 mx-2" data-bs-toggle="modal" data-bs-target="#error" data-bs-toggle="tooltip" data-bs-placement="top" title="For Demo Only" >Verify</button>

            <button type="button" class="btn btn-danger mb-3 mx-2" data-bs-toggle="modal" data-bs-target="#submitbtn">
                Submit
            </button>
            
        </center>      
        <!-- BUTTONS END -->

        <!-- POPUPS -->
            <!-- ERROR (for demo only) -->
            <div class="modal fade" id="error" tabindex="-1" >
                <div class="modal-dialog ">
                    <div class="modal-content ">
                    <div class="modal-header">
                        <h5 class="modal-title text-danger" id="error">ERROR</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        There is something wrong with the units. Note that units must be a total of 1-26.
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-success" data-bs-dismiss="modal">Try Again</button>
                    </div>
                    </div>
                </div>
            </div>

            <!-- CANCEL -->
            <div class="modal fade" id="cancelbtn" tabindex="-1" >
                <div class="modal-dialog">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="cancelbtn">Cancel</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        Are you sure you want to cancel this process?
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                        <button type="button"  class="btn btn-danger" onclick="history.back()">Yes</button>
                    </div>
                    </div>
                </div>
            </div>

            <!-- SUBMIT -->
            <div class="modal fade" id="submitbtn" tabindex="-1" >
                <div class="modal-dialog modal-dialog-centered">
                    <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title text-success" id="submitbtn">SUCCESS</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        Subjects has been successfully selected.
                    </div>
                    <div class="modal-footer">                     
                        <a href="student-iii.html" type="button" class="btn btn-dark">Okay</a>
                    </div>
                    </div>
                </div>
            </div>
         <!-- POPUPS END -->
	</div>
    


    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <script
      src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"
      integrity="sha384-q2kxQ16AaE6UbzuKqyBE9/u/KzioAlnx2maXQHiDX9d4/zp8Ok3f+M7DPm+Ib6IU"
      crossorigin="anonymous"
    ></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/js/bootstrap.min.js"
      integrity="sha384-pQQkAEnwaBkjpqZ8RU1fF1AKtTcHJwFl3pblpTlHXybJjHpMYo79HY3hIi4NKxyj"
      crossorigin="anonymous"
    ></script>

   	<script type="text/javascript" src="https://code.jquery.com/jquery-3.3.1.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.23/js/jquery.dataTables.js"></script>
	<script type="text/javascript" src="https://cdn.datatables.net/1.10.23/js/dataTables.bootstrap4.js"></script>

    <!-- SELECT/UNSELECT ALL -->
     <script>
        function checking() {
            document.getElementById('checking').checked = true;
            document.getElementById('checking').checked = true;
            document.getElementById('checking').checked = true;
            document.getElementById('checking').checked = true;
            document.getElementById('checking').checked = true;
            document.getElementById('checking').checked = true;
            document.getElementById('checking').checked = true;

            document.getElementById('checkboxAll').style.display = "none";
            document.getElementById('undo').style.display = "inline";
        }
        function unchecking() {
            document.getElementById('checking').checked = false;
            document.getElementById('checking').checked = false;
            document.getElementById('checking').checked = false;
            document.getElementById('checking').checked = false;
            document.getElementById('checking').checked = false;
            document.getElementById('checking').checked = false;
            document.getElementById('checking').checked = false;

            document.getElementById('checkboxAll').style.display = "inline";
            document.getElementById('undo').style.display = "none";
        }
    </script>

    <!-- TABLE -->
	<script>
		$('#mydatatable').DataTable({
			initComplete: function () {
				this.api().columns().every( function(){
					var column = this;
					var select = $('<select><option value=""></option></select>')
					.appendTo( $(column.footer()).empty() )
					.on( 'change', function () {
						var val = $.fn.DataTable.util.escapeRegex(
							$(this).val()
						);

						column
							.search( val ? '^'+val+'$' : '', true, false)
							.draw();
					});
					column.data().unique().sort().each( function (d,j) {
						select.append( '<option value="'+d+'">'+d+'</option>')
					});
				});
			}
		});
    </script>
    
    <!-- SCRIPTS -->
    <script src="//ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
  </body>
</html>
