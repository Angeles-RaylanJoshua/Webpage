<?php
    session_start();
    include("../../includes/config.php");

    if(isset($_POST['submit-grade']))
    {
        $Sub1=mysqli_real_escape_string($connection,$_POST['sub1']);
        $Sub2=mysqli_real_escape_string($connection,$_POST['sub2']);
        $Sub3=mysqli_real_escape_string($connection,$_POST['sub3']);
        $Sub4=mysqli_real_escape_string($connection,$_POST['sub4']);
        $Sub5=mysqli_real_escape_string($connection,$_POST['sub5']);
        $Sub6=mysqli_real_escape_string($connection,$_POST['sub6']);
        $Sub7=mysqli_real_escape_string($connection,$_POST['sub7']);
        $Sub8=mysqli_real_escape_string($connection,$_POST['sub8']);
        $Sub9=mysqli_real_escape_string($connection,$_POST['sub9']);
        $Sub10=mysqli_real_escape_string($connection,$_POST['sub10']);
        $Grade1=mysqli_real_escape_string($connection,$_POST['grade1']);
        $Grade2=mysqli_real_escape_string($connection,$_POST['grade2']);
        $Grade3=mysqli_real_escape_string($connection,$_POST['grade3']);
        $Grade4=mysqli_real_escape_string($connection,$_POST['grade4']);
        $Grade5=mysqli_real_escape_string($connection,$_POST['grade5']);
        $Grade6=mysqli_real_escape_string($connection,$_POST['grade6']);
        $Grade7=mysqli_real_escape_string($connection,$_POST['grade7']);
        $Grade8=mysqli_real_escape_string($connection,$_POST['grade8']);
        $grade9=mysqli_real_escape_string($connection,$_POST['grade9']);
        $grade10=mysqli_real_escape_string($connection,$_POST['grade10']);
        $Courseid=mysqli_real_escape_string($connection,$_POST['course']);
        $Collegeid=mysqli_real_escape_string($connection,$_POST['college']);
        $Year=mysqli_real_escape_string($connection,$_POST['year']);
        $Studentemail=mysqli_real_escape_string($connection,$_POST['email']);
        $First=mysqli_real_escape_string($connection,$_POST['firstname']);
        $Last=mysqli_real_escape_string($connection,$_POST['lastname']);
        $Getemail=mysqli_real_escape_string($connection,$_POST['adviser']);
        $Section = 'A';
        $GetStatus = 'Pending Approval';
        $Getid="";

       /* $sqli_s = mysqli_query($connection,"SELECT * FROM tblsub_grades WHERE student_email='$Studentemail' ");

        if(mysqli_num_rows($sqli_s) > 0)
        {
            $_SESSION['student_alert_message'] = "email";
            header("location: student-grade-input.php");
        }
        else{*/

            $sql2="INSERT INTO tblsub_grades (subject_code1,grades1,subject_code2,grades2,subject_code3,grades3,subject_code4,grades4,subject_code5,grades5,subject_code6,grades6,subject_code7,grades7,subject_code8,grades8,subject_code9,grades9,subject_code10,grades10,student_email,firstname,lastname,section,status,college_id_fk,courseid_fk,yearlevel,adviser_email) VALUES ('$Sub1','$Grade1','$Sub2','$Grade2','$Sub3','$Grade3','$Sub4','$Grade4','$Sub5','$Grade5','$Sub6','$Grade6','$Sub7','$Grade7','$Sub8','$Grade8','$Sub9','$grade9','$Sub10','$grade10','$Studentemail','$First','$Last','$Section','$GetStatus','$Collegeid','$Courseid','$Year','$Getemail')";

            if(mysqli_query($connection,$sql2))
            {
                $_SESSION['student_alert_message'] = "added";
                header("location: student-ii.php");
            }
            else
            {
                echo "ERROR:Could not be able to execute $sql2. " .mysqli_error($connection);
            }
        /*}*/
    }
?>