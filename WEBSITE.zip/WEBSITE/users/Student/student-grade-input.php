<?php
	session_start();
	include("../../includes/logout.php");
    include("../../includes/config.php");
    include("../../includes/studentalertmessage.php");
     
    $user_check = $_SESSION['login_user'];
    $user_col = $_SESSION['college_id_fk'];
    $user_cour = $_SESSION['courseid_fk'];
    $user_year = $_SESSION['yearlevel'];
	$query1 = mysqli_query($connection, "SELECT * FROM tblusers WHERE email = '$user_check'");
    while($fa = mysqli_fetch_array($query1))
    {
		$detectedfirst = $fa['firstname'];
		$detectedlast = $fa['lastname'];
		$detectedfull = ucfirst($detectedfirst).' '.ucfirst($detectedlast);
        $detected = $fa['college_id_fk'];
        $cour = $fa['courseid_fk'];
    }

    $query2 = mysqli_query($connection, "SELECT * FROM tblcourse WHERE collegeid_fk = '$detected'");
    while($fa = mysqli_fetch_array($query2))
    {
        $detectedcourseid = $fa['id'];
        $detectedcourse = $fa['course'];
        $detectedyear = $fa['yearlevels'];
    }

    $query3 = mysqli_query($connection, "SELECT * FROM tblsections");
    while($sa = mysqli_fetch_array($query3))
    {
        $detectedsecid = $sa['id'];
        $detectedseccode = $sa['sectioncode'];
        $detectedsecname = $sa['section_name'];
        $detectedsecAvail = $sa['available_slots'];
        $detectedsecNum = $sa['number_of_students'];
        $detectedTotal = $detectedsecAvail - $detectedsecNum;
        $detectedseccol = $sa['college'];
    }

    $sql1=mysqli_query($connection,"SELECT * FROM tblusers WHERE usertype='Adviser' and college_id_fk='$user_col' and courseid_fk='$user_cour' and yearlevel='$user_year'");

    while($da = mysqli_fetch_array($sql1))
    {
        $Getid = $da['id'];
        $Getemail = $da['email'];
        $Getcour = $da['courseid_fk'];
        $Getcolid=$da['college_id_fk'];
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <!--Let browser know website is optimized for mobile-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <!-- BOOTSTRAP -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.23/css/dataTables.bootstrap4.css" />
    

    <!-- fontawesome -->
    <link
        rel="stylesheet"
        href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p"
        crossorigin="anonymous"
    />
    <link rel="stylesheet" href="../../bootstrap/fontawesome.min.css" />
    <!-- local css -->
    <link rel="stylesheet" href="../../css/style-student.css" />

    <title>Submit Grade</title>
</head>
<body>
    <!-- NAVBAR -->
    <nav class="navbar navbar-expand-lg navbar-dark" id="navbar">
        <div class="container-fluid">
            <!-- ICS LOGO -->
            <a class="navbar-brand p-0 m-0" href="#" id="nav-logo">
            <?php 
                    $user_check = $_SESSION['login_user'];
                    $query1 = mysqli_query($connection, "SELECT * FROM tblusers WHERE email = '$user_check'");
						while($getcollege = mysqli_fetch_array($query1))
						{ 
							$college_check = $getcollege['college_id_fk'];
							$getdata = mysqli_query($connection,"SELECT * FROM tblcollege WHERE id='$college_check'");

							while($fa = mysqli_fetch_array($getdata))
							{
								$boom = $fa['seal'];
								echo "<span id='department'>  "."<img style='width: 2rem; height: 2rem; margin-right: 10px;' src='../SuperAdmin/images/$boom'>".$fa['college']."</span>";
							}
						}							
					?> 
            </a>

            <!-- MOBILE TOGGLE -->
            <button
                class="navbar-toggler m-0"
                type="button"
                data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent"
                aria-controls="navbarSupportedContent"
                aria-expanded="false"
                aria-label="Toggle navigation"
            >
                <span><i class="fas fa-bars"></i></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav">
                    <!-- logout -->
                    <li class="nav-item" data-bs-toggle="tooltip" data-bs-placement="bottom" title="Logout">
                        <a id="icons" class="nav-link active py-0" href="../../signin/universal-signin.php" aria-disabled="true"><i class="fas fa-sign-out-alt"></i><span class="nav-label"> Logout</span></a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- END OF NAVBAR -->

    <!-- CONTENT -->
    <div class="container container-fluid overflow-auto" id="desktop-view">
    <form action="managegradesubmissions.php" method="POST">
        <h2 class="text fw-bold text-center mt-4">Submit your grades</h2>
        <h4 class="text-center fw-light">via Manual Input</h4>

        <!-- Choices -->
        <div class="container container-fluid p-3 mt-5">
            <div class="row">
                <!-- Manual Input -->
                <div class="col-sm-6 ">
                    
                    <div class="choice container container-fluid p-3 rounded " style="height: 100%;" >
                        <p class="badge fs-5 bg-danger rounded-circle">1</p>
                        <p class="text-center">Manually input your grades here:</p>
                        <table class="table table-responsive table-sm mt-3 table-striped table-bordered table-hover table-fixed" id="myTawable">
                            <thead class="text-white bg-secondary">
                                <th>Subject</th>
                                <th>Grades</th>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>
                                        <input type="text" name="sub1" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                    <td>
                                        <input type="text" name="grade1" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="text" name="sub2" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                    <td>
                                        <input type="text" name="grade2" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="text" name="sub3" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                    <td>
                                        <input type="text" name="grade3" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="text" name="sub4" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                    <td>
                                        <input type="text" name="grade4" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="text" name="sub5" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                    <td>
                                        <input type="text" name="grade5" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="text" name="sub6" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                    <td>
                                        <input type="text" name="grade6" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="text" name="sub7" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                    <td>
                                        <input type="text" name="grade7" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="text" name="sub8" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                    <td>
                                        <input type="text" name="grade8" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="text" name="sub9" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                    <td>
                                        <input type="text" name="grade9" placeholder="Enter here..." class="w-100 border-0 bg-light" required />
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <input type="text" name="sub10" placeholder="Enter here..." class="w-100 border-0 bg-light" />
                                    </td>
                                    <td>
                                        <input type="text" name="grade10" placeholder="Enter here..." class="w-100 border-0 bg-light" />
                                    </td>
                                </tr>
                                <input type="hidden" name="email" value="<?php echo $user_check?>" class="w-100 border-0 bg-light" />
                                <input type="hidden" name="course" value="<?php echo $user_cour?>" class="w-100 border-0 bg-light" />
                                <input type="hidden" name="firstname" value="<?php echo $detectedfirst?>" class="w-100 border-0 bg-light" />
                                <input type="hidden" name="lastname" value="<?php echo $detectedlast?>" class="w-100 border-0 bg-light" />
                                <input type="hidden" name="college" value="<?php echo $user_col?>" class="w-100 border-0 bg-light" />
                                <input type="hidden" name="year" value="<?php echo $user_year?>" class="w-100 border-0 bg-light" />
                                <input type="hidden" name="adviser" value="<?php echo $Getemail?>" class="w-100 border-0 bg-light" />
                                
                                
                            </tbody>
                        </table>
                    </div>
                </div>

                <div class="col-sm-1 mt-5">
                </div>
    
                <!-- MANUAL INPUT -->
                <div class="col-sm-5">
                    <div class="choice container container-fluid p-3 rounded "  style="height: 100%; margin-bottom: 50px;">

                        <p class="badge fs-5 bg-danger rounded-circle">2</p>
                        <!--<a href="" class="btn w-100 mt-3 btn-dark mb-5"><span class="float-start"><i class="fas fa-qrcode"></i></span> Add Input Text Box</a>-->

                       
                        <!-- POPUP HELP -->
                        <button type="button" class="btn  btn-secondary w-100 mb-2" data-bs-toggle="modal" data-bs-target="#help">
                            <span class="float-start"><i class="fas fa-question"></i></span> Help
                        </button>

                        <a onclick="history.back()" class="btn bg-secondary text-white w-100 mb-2">
                            <span class="float-start"><i class="fas fa-arrow-left"></i></span>Back
                        </a>
                        <button type="submit" name="submit-grade" class="btn w-100 btn-danger" data-bs-toggle="modal" data-bs-target="#help">
                            <span class="float-start"><i class="fas fa-check"></i></span> Submit
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Container of Choices END-->

       

        <!-- HELP POPUP -->
        <div class="modal fade" id="help" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Manual Input Help</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        
                        
                        <p>Manually input your grades if you are having trouble with the QR Code. Or your grades haven't been uploaded yet.<br> <br>
                            <a href="http://wmsu.edu.ph/">Check your grades from the WMSU Portal</a></p>
                    </div>
                    
                </div>
            </div>
        </div>
        <!-- HELP POPUP END -->
    </form>
    </div>
    <!-- CONTENT END -->


    <!-- To Read QR Code -->
    <script type="text/javascript" src="../../bootstrap/qrReader.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    
    <script>
        function myCreateFunction() {
            var table = document.getElementById("myTable");
            var row = table.insertRow(0);
            var cell1 = row.insertCell(0);
            var cell2 = row.insertCell(1);
            cell1.innerHTML = "NEW CELL1";
            cell2.innerHTML = "NEW CELL2";
        }

        function myDeleteFunction() {
            document.getElementById("myTable").deleteRow(0);
        }
    </script>
</body>
</html>